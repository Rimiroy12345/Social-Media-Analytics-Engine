'use strict';

require('dotenv').config();
const path = require('path');
const express = require('express');
const api = require('./routes/api');
const { pool } = require('./db/pool');
const { ensureDatabase } = require('./db/bootstrap');

const app = express();
const PORT = process.env.PORT || 3000;

app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));

// Simple request log: method, path, status, duration.
app.use((req, res, next) => {
  const started = Date.now();
  res.on('finish', () => {
    console.log(`${req.method} ${req.originalUrl} ${res.statusCode} ${Date.now() - started}ms`);
  });
  next();
});

app.use('/api', api);
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

app.use((req, res) => {
  if (req.path.startsWith('/api')) return res.status(404).json({ error: 'No such endpoint' });
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const server = app.listen(PORT, () => {
  console.log(`Social Media Analytics Engine listening on http://localhost:${PORT}`);
  // Start serving immediately, then create and seed the database if it is new.
  // The page shows a setup screen and polls /api/status until this finishes.
  ensureDatabase();
});

// Render sends SIGTERM when it redeploys or spins the service down.
for (const signal of ['SIGTERM', 'SIGINT']) {
  process.on(signal, () => {
    console.log(`\n${signal} received, closing down.`);
    server.close(() => pool.end().then(() => process.exit(0)));
  });
}
