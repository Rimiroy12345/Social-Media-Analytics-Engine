'use strict';

/**
 * Every analytical query the app can run lives here.
 *
 * Keeping them in one catalog means the API never executes a string that
 * came from the browser: the client sends an id, the server looks it up.
 * It also means the UI can show the exact SQL next to its result.
 */

const QUERIES = [
  {
    id: 'top_posts',
    title: 'Highest engagement posts',
    question: 'Which posts collected the most interactions, and what is the mix?',
    concepts: ['JOIN', 'GROUP BY', 'HAVING', 'FILTER'],
    sql: `SELECT p.post_id,
       u.username AS author,
       p.topic,
       SUM(CASE WHEN i.interaction_type = 'like' THEN 1 ELSE 0 END) AS likes,
       SUM(CASE WHEN i.interaction_type = 'share' THEN 1 ELSE 0 END) AS shares,
       SUM(CASE WHEN i.interaction_type = 'save' THEN 1 ELSE 0 END) AS saves,
       count(*) AS total_interactions,
       count(DISTINCT i.user_id) AS unique_people
FROM posts p
JOIN users u ON u.user_id = p.user_id
JOIN interactions i ON i.post_id = p.post_id
GROUP BY p.post_id, u.username, p.topic
HAVING count(*) >= 40
ORDER BY total_interactions DESC
LIMIT 20;`
  },

  {
    id: 'rank_users',
    title: 'Creator leaderboard',
    question: 'How do creators rank once every engagement type is weighted?',
    concepts: ['CTE', 'RANK()', 'DENSE_RANK()', 'PERCENT_RANK()'],
    sql: `WITH author_stats AS (
    SELECT u.user_id,
           u.username,
           u.country,
           count(pe.post_id) AS posts,
           COALESCE(sum(pe.engagement_score), 0)    AS engagement_score
    FROM users u
    LEFT JOIN v_post_engagement pe ON pe.author_id = u.user_id
    GROUP BY u.user_id, u.username, u.country
    HAVING count(pe.post_id) > 0
)
SELECT username,
       country,
       posts,
       engagement_score,
       round(engagement_score / posts, 1) AS score_per_post,
       RANK() OVER (ORDER BY engagement_score DESC) AS overall_rank,
       DENSE_RANK() OVER (ORDER BY engagement_score DESC) AS rank_dense,
       RANK() OVER (PARTITION BY country
                          ORDER BY engagement_score DESC) AS rank_in_country,
       ROUND(PERCENT_RANK() OVER (ORDER BY engagement_score) * 100, 1) AS percentile
FROM author_stats
ORDER BY engagement_score DESC
LIMIT 25;`
  },

  {
    id: 'trending',
    title: 'Trending in the last 7 days',
    question: 'What is gaining momentum right now, counting only this week\u2019s activity?',
    concepts: ['CTE', 'UNION ALL', 'weighted SUM', 'DENSE_RANK()', 'date filtering'],
    benchmark: true,
    note: 'Trending means activity in the window, not posts published in the window. An older post people are reacting to this week counts; a post published this week that nobody touched does not. GenerateTrendingPostReport applies exactly this rule with a cursor.',
    sql: `WITH events AS (
    SELECT i.post_id,
           CASE i.interaction_type
               WHEN 'view' THEN 0.2
               WHEN 'like' THEN 1.0
               WHEN 'save' THEN 2.0
               WHEN 'share' THEN 3.0
           END AS points,
           1 AS is_interaction
    FROM interactions i
    WHERE i.created_at >= NOW() - INTERVAL 7 DAY
    UNION ALL
    SELECT c.post_id, 2.0 AS points, 0 AS is_interaction
    FROM comments c
    WHERE c.created_at >= NOW() - INTERVAL 7 DAY
),
scored AS (
    SELECT post_id,
           ROUND(SUM(points), 1) AS trend_score,
           SUM(is_interaction) AS interactions,
           COUNT(*) - SUM(is_interaction) AS comments
    FROM events
    GROUP BY post_id
)
SELECT DENSE_RANK() OVER (ORDER BY s.trend_score DESC) AS trend_rank,
       s.post_id,
       u.username AS author,
       p.topic,
       p.post_type,
       s.interactions,
       s.comments,
       s.trend_score,
       TIMESTAMPDIFF(DAY, p.created_at, NOW()) AS post_age_days
FROM scored s
JOIN posts p ON p.post_id = s.post_id
JOIN users u ON u.user_id = p.user_id
ORDER BY s.trend_score DESC
LIMIT 20;`
  },

  {
    id: 'recent_activity',
    title: 'Who has been active in the last 3 days',
    question: 'Which people have been reacting to things this week, and how much?',
    concepts: ['Narrow date filter', 'JOIN', 'GROUP BY', 'conditional aggregate'],
    benchmark: true,
    note: 'Three days out of six months is a small slice, which is exactly when an index earns its keep. Try this one in the index lab.',
    sql: `SELECT u.user_id,
       u.username,
       u.country,
       COUNT(*) AS actions,
       SUM(CASE WHEN i.interaction_type = 'like' THEN 1 ELSE 0 END) AS likes,
       SUM(CASE WHEN i.interaction_type = 'share' THEN 1 ELSE 0 END) AS shares,
       COUNT(DISTINCT i.post_id) AS posts_touched,
       MAX(i.created_at) AS last_seen
FROM interactions i
JOIN users u ON u.user_id = i.user_id
WHERE i.created_at >= NOW() - INTERVAL 3 DAY
GROUP BY u.user_id, u.username, u.country
ORDER BY actions DESC
LIMIT 20;`
  },

  {
    id: 'post_vs_author_avg',
    title: 'Post performance against its author',
    question: 'Which posts beat their own author\u2019s usual numbers, and by how much?',
    concepts: ['Window AVG', 'PARTITION BY', 'CASE', 'CTE'],
    sql: `WITH regular_authors AS (
    SELECT author_id
    FROM v_post_engagement
    GROUP BY author_id
    HAVING count(*) >= 8
),
scored AS (
    SELECT pe.author_id,
           pe.author,
           pe.post_id,
           pe.post_type,
           DATE(pe.posted_at) AS posted_on,
           pe.engagement_score,
           round(avg(pe.engagement_score) OVER (PARTITION BY pe.author_id), 1) AS author_average
    FROM v_post_engagement pe
    JOIN regular_authors ra ON ra.author_id = pe.author_id
)
SELECT author,
       post_id,
       post_type,
       posted_on,
       engagement_score,
       author_average,
       round(engagement_score - author_average, 1) AS difference,
       CASE
           WHEN engagement_score > author_average * 2 THEN 'breakout'
           WHEN engagement_score > author_average THEN 'above average'
           ELSE 'below average'
       END AS verdict
FROM scored
ORDER BY difference DESC
LIMIT 25;`
  },

  {
    id: 'daily_trend',
    title: 'Daily activity with a 7 day moving average',
    question: 'Is the platform getting busier, once daily noise is smoothed out?',
    concepts: ['Window frame ROWS BETWEEN', 'LAG()', 'DATE()'],
    sql: `WITH daily AS (
    SELECT DATE(created_at) AS activity_date,
           count(*) AS interactions,
           count(DISTINCT user_id) AS active_users
    FROM interactions
    WHERE created_at >= NOW() - INTERVAL 45 DAY
    GROUP BY DATE(created_at)
)
SELECT activity_date,
       interactions,
       active_users,
       round(avg(interactions) OVER (ORDER BY activity_date
                                     ROWS BETWEEN 6 PRECEDING AND CURRENT ROW), 1)
                                                        AS moving_avg_7d,
       interactions - LAG(interactions) OVER (ORDER BY activity_date)
                                                        AS change_vs_yesterday,
       sum(interactions) OVER (ORDER BY activity_date) AS running_total
FROM daily
ORDER BY activity_date;`
  },

  {
    id: 'top_per_author',
    title: 'Each creator\u2019s best three posts',
    question: 'What is the top of every active creator\u2019s catalogue?',
    concepts: ['ROW_NUMBER()', 'PARTITION BY', 'filtering on a window result'],
    sql: `WITH numbered AS (
    SELECT author,
           author_id,
           post_id,
           post_type,
           engagement_score,
           ROW_NUMBER() OVER (PARTITION BY author_id
                              ORDER BY engagement_score DESC, post_id) AS rn,
           count(*) OVER (PARTITION BY author_id) AS total_posts
    FROM v_post_engagement
)
SELECT author, total_posts, rn AS position, post_id, post_type, engagement_score
FROM numbered
WHERE rn <= 3 AND total_posts >= 10
ORDER BY author, rn
LIMIT 60;`
  },

  {
    id: 'above_avg_followers',
    title: 'Users above the average follower count',
    question: 'Who is more followed than the typical account on the platform?',
    concepts: ['Correlated subquery', 'Scalar subquery', 'Derived table'],
    note: 'Written with correlated subqueries on purpose, to show what that costs. In MySQL the follower lookups are already indexed, because InnoDB indexes every foreign key for you.',
    sql: `SELECT u.username,
       u.country,
       (SELECT count(*) FROM followers f WHERE f.followee_id = u.user_id) AS followers,
       (SELECT count(*) FROM followers f WHERE f.follower_id = u.user_id) AS following,
       (SELECT count(*) FROM posts p    WHERE p.user_id     = u.user_id) AS posts
FROM users u
WHERE (SELECT count(*) FROM followers f WHERE f.followee_id = u.user_id) >
      (SELECT avg(follower_count)
       FROM (SELECT count(*) AS follower_count
             FROM followers
             GROUP BY followee_id) AS per_user)
ORDER BY followers DESC
LIMIT 25;`
  },

  {
    id: 'hourly_pattern',
    title: 'When the platform is awake',
    question: 'Which hours of the day carry the most engagement?',
    concepts: ['HOUR()', 'GROUP BY', 'Window SUM for share of total'],
    sql: `SELECT HOUR(created_at)                   AS hour_of_day,
       count(*) AS interactions,
       SUM(CASE WHEN interaction_type = 'like' THEN 1 ELSE 0 END) AS likes,
       SUM(CASE WHEN interaction_type = 'share' THEN 1 ELSE 0 END) AS shares,
       round(100.0 * count(*) / sum(count(*)) OVER (), 2) AS pct_of_all_activity
FROM interactions
GROUP BY hour_of_day
ORDER BY hour_of_day;`
  },

  {
    id: 'quiet_users',
    title: 'Accounts that never engage',
    question: 'Who has registered but never liked, shared, saved or viewed anything?',
    concepts: ['NOT EXISTS', 'Anti-join', 'LEFT JOIN alternative'],
    note: 'An anti-join. In MySQL this one stays fast even with the secondary indexes dropped, because the foreign key on interactions.user_id brings its own index.',
    sql: `SELECT u.user_id,
       u.username,
       u.country,
       DATE(u.created_at) AS joined_on,
       (SELECT count(*) FROM posts p WHERE p.user_id = u.user_id)      AS posts_written
FROM users u
WHERE NOT EXISTS (
        SELECT 1 FROM interactions i WHERE i.user_id = u.user_id
      )
ORDER BY u.created_at DESC
LIMIT 25;`
  },

  {
    id: 'interaction_mix',
    title: 'Interaction mix of the busiest posts',
    question: 'For the most active posts, how is engagement split between action types?',
    concepts: ['Window SUM OVER PARTITION', 'percentage of total', 'CTE'],
    sql: `WITH busiest AS (
    SELECT post_id
    FROM interactions
    GROUP BY post_id
    ORDER BY count(*) DESC
    LIMIT 10
),
mix AS (
    SELECT i.post_id,
           i.interaction_type,
           count(*) AS n,
           sum(count(*)) OVER (PARTITION BY i.post_id) AS post_total
    FROM interactions i
    JOIN busiest b ON b.post_id = i.post_id
    GROUP BY i.post_id, i.interaction_type
)
SELECT m.post_id,
       u.username AS author,
       m.interaction_type,
       m.n AS interactions,
       m.post_total,
       round(100.0 * m.n / m.post_total, 1) AS pct_of_post
FROM mix m
JOIN posts p ON p.post_id = m.post_id
JOIN users u ON u.user_id = p.user_id
ORDER BY m.post_total DESC, m.n DESC;`
  },

  {
    id: 'mutual_follows',
    title: 'Mutual connections',
    question: 'Which pairs of users follow each other back?',
    concepts: ['Self join', 'Avoiding duplicate pairs', 'Composite key'],
    sql: `SELECT a.username        AS user_a,
       b.username AS user_b,
       DATE(f1.followed_at) AS a_followed_b,
       DATE(f2.followed_at) AS b_followed_a
FROM followers f1
JOIN followers f2 ON f1.follower_id = f2.followee_id
                 AND f1.followee_id = f2.follower_id
JOIN users a ON a.user_id = f1.follower_id
JOIN users b ON b.user_id = f1.followee_id
WHERE f1.follower_id < f1.followee_id
ORDER BY f1.followed_at DESC
LIMIT 25;`
  },

  {
    id: 'type_performance',
    title: 'Which format performs best',
    question: 'Do videos really beat text posts once you divide by how many were published?',
    concepts: ['Aggregate functions', 'GROUP BY', 'Ratio comparison'],
    sql: `SELECT post_type,
       count(*) AS posts_published,
       sum(total_interactions) AS total_interactions,
       round(avg(total_interactions), 1) AS avg_interactions_per_post,
       round(avg(engagement_score), 1) AS avg_engagement_score,
       max(engagement_score) AS best_single_post,
       round(100.0 * count(*) / sum(count(*)) OVER (), 1) AS pct_of_all_posts
FROM v_post_engagement
GROUP BY post_type
ORDER BY avg_engagement_score DESC;`
  },

  {
    id: 'follower_growth',
    title: 'Follower growth month by month',
    question: 'How did the follower graph grow over time, cumulatively?',
    concepts: ['DATE_FORMAT', 'Running total', 'Window SUM'],
    sql: `WITH monthly AS (
    SELECT DATE_FORMAT(followed_at, '%Y-%m-01') AS month,
           count(*) AS new_follows
    FROM followers
    GROUP BY 1
)
SELECT month,
       new_follows,
       sum(new_follows) OVER (ORDER BY month) AS cumulative_follows,
       new_follows - LAG(new_follows) OVER (ORDER BY month)              AS change_vs_prev_month,
       round(100.0 * new_follows / sum(new_follows) OVER (), 1) AS pct_of_all_follows
FROM monthly
ORDER BY month;`
  }
];

const byId = new Map(QUERIES.map((q) => [q.id, q]));

module.exports = {
  QUERIES,
  getQuery: (id) => byId.get(id),
  /** Public catalog without anything the client should not need. */
  listQueries: () =>
    QUERIES.map(({ id, title, question, concepts, sql, note, benchmark }) => ({
      id,
      title,
      question,
      concepts,
      sql,
      note: note || null,
      benchmark: Boolean(benchmark)
    }))
};
