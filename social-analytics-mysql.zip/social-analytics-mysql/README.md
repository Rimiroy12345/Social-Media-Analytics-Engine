# Social Media Analytics Engine — MySQL edition

A relational database system that stores social media activity and analyses it with advanced SQL: window functions, CTEs, correlated subqueries, views, and measurable index tuning.

Every number the website shows is produced by a SQL query that runs when you load the page, and the app shows you that SQL.

```
MySQL 8.0        ←  Node.js + Express API  ←  vanilla JS frontend
  5 tables + 4 support   14 catalog queries      7 sections, SVG charts
  3 views                EXPLAIN + timings       no build step
  9 indexes              CRUD endpoints          no CDN dependency
  3 functions
  2 cursor procedures
  3 triggers
```

Point it at an empty MySQL database and it builds itself: schema, views, indexes and roughly 180,000 rows of generated activity, on first boot.

---

## What you need

- **MySQL 8.0 or newer.** The project uses window functions (`RANK`, `ROW_NUMBER`, `LAG`) and common table expressions, neither of which exists in MySQL 5.7. Check with `SELECT VERSION();`
- **Node.js 18 or newer.**

XAMPP, WAMP, MySQL Workbench and a standalone MySQL server all work — the app only needs a host, a user and a database name.

---

## Getting it running

```bash
npm install
```

Create an empty database. In MySQL Workbench, or at the command line:

```sql
CREATE DATABASE social_analytics;
```

Tell the app how to reach it:

```bash
cp .env.example .env
```

Then edit `.env`. For XAMPP the defaults usually work as they are (`root`, no password). For a standalone MySQL install, set `DB_PASSWORD` to the root password you chose, or use a user you created.

```bash
npm start
```

Open http://localhost:3000. On the first run the server finds an empty database, creates the tables, views and indexes, generates the dataset, and shows its progress while it works. That takes about nine seconds and happens once. Every later start reuses what is there.

### Or with Docker

```bash
docker compose up
```

That starts MySQL and the app together and needs no `.env` file.

### Scripts

| Command | What it does |
|---|---|
| `npm start` | Start the server, setting the database up if it is empty |
| `npm run dev` | Same, restarting when files change |
| `npm run db:setup` | Create tables, views and indexes if missing |
| `npm run db:fresh` | Drop everything and recreate it empty |
| `npm run db:seed` | Fill the tables with generated data |
| `npm run db:reset` | `db:fresh` followed by `db:seed` |

Set `AUTO_SETUP=false` to stop the server touching the schema and use the scripts instead.

---

## Stored programs

`db/programs.sql` holds the procedural layer, and the app loads it automatically after the data. The file uses `DELIMITER $$`, so it also pastes straight into MySQL Workbench.

| Object | Kind | What it does |
|---|---|---|
| `CalculatePostEngagement(post_id)` | function | Weighted score for one post |
| `CalculateUserEngagement(user_id)` | function | Total points for a creator |
| `CalculateWindowEngagement(post_id, start, end)` | function | Points earned between two moments — what "trending" measures |
| `GenerateUserEngagementReport(user_id)` | procedure, cursor | Walks a creator's posts row by row, stores a summary |
| `GenerateTrendingPostReport(start, end, limit)` | procedure, cursor | Walks every post with activity in the window, scores that window only, rebuilds the trending report |
| `trg_no_self_engagement` | trigger, BEFORE INSERT | Refuses a self-like; raises SIGNAL SQLSTATE '45000' |
| `trg_interaction_audit` | trigger, AFTER INSERT | Logs every interaction to `interaction_audit` |
| `trg_post_delete_audit` | trigger, AFTER DELETE | Records deleted posts in `post_audit` |

All seven are demonstrable from the **Procedures & triggers** page, which also carries the CRUD flow: create a post, react to it, watch the integrity trigger refuse a self-like, delete it, and see the audit trail update.

`docs/REVIEW-2-SUBMISSION.md` writes all of this up in the form the review asks for: DDL and constraints, thirteen query requirements in English, and the scenario behind every procedure, function, trigger and cursor.

---

## Connecting with MySQL Workbench

The app and Workbench can both be connected at once — they are just two clients.

1. In Workbench, open your local connection and run `USE social_analytics;`
2. `SHOW TABLES;` lists the five tables and three views.
3. Anything the query lab shows you can be pasted straight into a Workbench query tab. The SQL is the same text.

That is worth demonstrating in a viva: the website is not holding the data, MySQL is.

---

## Things that differ from the PostgreSQL version

If you are comparing against the other edition, or writing about dialects in your report:

| | PostgreSQL | MySQL |
|---|---|---|
| Conditional count | `count(*) FILTER (WHERE ...)` | `SUM(CASE WHEN ... THEN 1 ELSE 0 END)` |
| Date part | `EXTRACT(hour FROM ts)` | `HOUR(ts)` |
| Truncate to month | `date_trunc('month', ts)` | `DATE_FORMAT(ts, '%Y-%m-01')` |
| Interval | `now() - INTERVAL '7 days'` | `NOW() - INTERVAL 7 DAY` |
| Cast to date | `ts::date` | `DATE(ts)` |
| Case-insensitive match | `ILIKE` | `LIKE` (default collation) |
| Create index if absent | `CREATE INDEX IF NOT EXISTS` | not supported — the app checks `information_schema` first |
| Partial index | `... WHERE type = 'share'` | not supported |
| Timing a query | `EXPLAIN (ANALYZE, BUFFERS)` | `EXPLAIN` for the plan, timing measured around the query |
| `DENSE_RANK` as a column alias | allowed | reserved word, so the alias is `rank_dense` |

**The big one: InnoDB creates an index for every foreign key automatically.** PostgreSQL does not. That is why this edition has nine indexes rather than ten, why `posts.user_id` and `interactions.user_id` are not in the list, and why the index lab's results are more modest here. It is a real difference between the two systems and a good thing to be able to explain.

---

## API reference

| Method | Endpoint | Returns |
|---|---|---|
| GET | `/api/health` | Server time and MySQL version |
| GET | `/api/status` | First-run setup progress; everything else returns 503 until ready |
| GET | `/api/overview` | Totals, 45-day series, top posts, top users, interaction mix |
| GET | `/api/users?search=&sort=&limit=` | Users with engagement metrics |
| GET | `/api/users/:id` | One user, their best posts, their latest activity |
| GET | `/api/posts?search=&type=&limit=` | Posts with engagement metrics |
| GET | `/api/queries` | The query catalog, including the SQL text |
| POST | `/api/queries/:id/run` | Runs one catalog query, returns rows and timing |
| POST | `/api/sql` | Runs a user-written SELECT, read only, capped at 200 rows |
| GET | `/api/indexes` | Every index on the database, and who created it |
| POST | `/api/indexes/enable` \| `/disable` | Creates or drops the nine project indexes |
| POST | `/api/benchmark` | Timings plus what `EXPLAIN` reported |
| GET | `/api/schema` | Columns, constraints and row counts from `information_schema` |

### SQL injection, if you are asked

The browser never sends SQL the server trusts. Catalog queries are looked up by id. Search endpoints use placeholders (`?`), so user text is never concatenated into SQL; sort columns are checked against an allow-list because a column name cannot be a placeholder. The SQL console accepts a single `SELECT` or `WITH`, blocks write keywords, runs inside `START TRANSACTION READ ONLY` with `MAX_EXECUTION_TIME` set, wraps the query in an outer `LIMIT 200`, and rolls back. `ALLOW_CUSTOM_SQL=false` switches it off.

---

## Measured results

600 users, 6,000 posts, 24,000 comments, 14,000 follows, 177,342 interactions, on MySQL 8.0.46. Average of three runs.

| Query | No project indexes | With them | Change | EXPLAIN says |
|---|---|---|---|---|
| Who has been active in the last 3 days | 86 ms | 38 ms | **2.3× faster** | `ALL` → `range` |
| Trending in the last 7 days | 65 ms | 61 ms | no real change | scans either way |
| Daily activity, 45 days | 72 ms | 67 ms | no real change | scans either way |
| Accounts that never engage | 12 ms | 12 ms | already fast | uses the foreign key's own index |

The rows with no change are not failures, they are the point. *Last 3 days* is a narrow slice — three days out of six months — so an index on `created_at` lets MySQL jump straight to it, and the access type visibly flips from `ALL` to `range`. The seven and forty-five day windows read enough of the table that a full scan is genuinely cheaper, and the optimiser ignores the index. *Accounts that never engage* is fast either way because InnoDB already indexed `interactions.user_id` for the foreign key.

Re-run the numbers on your own machine and quote what you measure.
