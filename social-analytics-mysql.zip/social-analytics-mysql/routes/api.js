'use strict';

const express = require('express');
const { pool, timedQuery } = require('../db/pool');
const { getStatus } = require('../db/bootstrap');
const { INDEXES, listPresent, createAll, dropAll } = require('../db/indexes');
const { getQuery, listQueries } = require('../queries/catalog');

const router = express.Router();
const ALLOW_CUSTOM_SQL = process.env.ALLOW_CUSTOM_SQL !== 'false';
const STATEMENT_TIMEOUT = process.env.STATEMENT_TIMEOUT || '8s';

/** Wraps an async handler so a rejected promise becomes a 500 with a message. */
const wrap = (fn) => (req, res) => {
  Promise.resolve(fn(req, res)).catch((err) => {
    console.error(`${req.method} ${req.originalUrl} failed:`, err.message);
    res.status(500).json({ error: err.message });
  });
};

// ---------------------------------------------------------------- setup ---
// Reports first-run progress so the page can show a setup screen.
router.get('/status', (_req, res) => res.json(getStatus()));

// Everything below needs a database that actually has tables in it.
router.use((req, res, next) => {
  const state = getStatus();
  if (state.ready || req.path === '/health') return next();
  res.status(503).json({
    error: state.error || 'The database is still being set up',
    setup: state
  });
});

// ---------------------------------------------------------------- health ---
router.get(
  '/health',
  wrap(async (_req, res) => {
    const [rows] = await pool.query('SELECT NOW() AS server_time, VERSION() AS version');
    res.json({ status: 'ok', ...rows[0] });
  })
);

// ------------------------------------------------------------- dashboard ---
router.get(
  '/overview',
  wrap(async (_req, res) => {
    const [totals, daily, mix, topPosts, topUsers, types] = await Promise.all([
      pool.query(`
        SELECT (SELECT COUNT(*) FROM users)        AS users,
               (SELECT COUNT(*) FROM posts)        AS posts,
               (SELECT COUNT(*) FROM comments)     AS comments,
               (SELECT COUNT(*) FROM followers)    AS follows,
               (SELECT COUNT(*) FROM interactions) AS interactions,
               (SELECT DATE(MIN(created_at)) FROM interactions) AS first_activity,
               (SELECT DATE(MAX(created_at)) FROM interactions) AS last_activity,
               (SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024) 
                  FROM information_schema.tables WHERE table_schema = DATABASE()) AS database_size_mb
      `),
      pool.query(`
        SELECT activity_date, interactions, active_users, likes, shares
        FROM v_daily_engagement
        WHERE activity_date >= (CURRENT_DATE - INTERVAL 45 DAY)
        ORDER BY activity_date
      `),
      pool.query(`
        SELECT interaction_type, COUNT(*) AS n
        FROM interactions GROUP BY interaction_type ORDER BY n DESC
      `),
      pool.query(`
        SELECT post_id, author, topic, post_type, likes, comments, shares, engagement_score
        FROM v_post_engagement
        ORDER BY engagement_score DESC LIMIT 8
      `),
      pool.query(`
        SELECT username, country, posts, engagement_score, followers
        FROM v_user_engagement
        ORDER BY engagement_score DESC LIMIT 8
      `),
      pool.query(`
        SELECT post_type, COUNT(*) AS posts, ROUND(AVG(engagement_score), 1) AS avg_score
        FROM v_post_engagement GROUP BY post_type ORDER BY avg_score DESC
      `)
    ]);

    const summary = totals[0][0];
    res.json({
      totals: { ...summary, database_size: `${summary.database_size_mb} MB` },
      daily: daily[0],
      mix: mix[0],
      topPosts: topPosts[0],
      topUsers: topUsers[0],
      byType: types[0]
    });
  })
);

// ----------------------------------------------------------------- users ---
router.get(
  '/users',
  wrap(async (req, res) => {
    const search = (req.query.search || '').trim();
    const sort = ['engagement_score', 'followers', 'posts', 'username'].includes(req.query.sort)
      ? req.query.sort
      : 'engagement_score';
    const direction = sort === 'username' ? 'ASC' : 'DESC';
    const limit = Math.min(Number(req.query.limit) || 25, 100);

    const [rows] = await pool.query(
      `SELECT user_id, username, full_name, country, posts, followers, following,
              engagement_score, avg_score_per_post, DATE(joined_at) AS joined_on
       FROM v_user_engagement
       WHERE (? = '' OR username LIKE CONCAT('%', ?, '%') OR full_name LIKE CONCAT('%', ?, '%'))
       ORDER BY ${sort} ${direction}
       LIMIT ?`,
      [search, search, search, limit]
    );
    res.json(rows);
  })
);

router.get(
  '/users/:id',
  wrap(async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'user id must be a number' });

    const [profile, posts, recent] = await Promise.all([
      pool.query('SELECT * FROM v_user_engagement WHERE user_id = ?', [id]),
      pool.query(
        `SELECT post_id, topic, post_type, DATE(posted_at) AS posted_on, likes, comments,
                shares, views, engagement_score
         FROM v_post_engagement WHERE author_id = ?
         ORDER BY engagement_score DESC LIMIT 10`,
        [id]
      ),
      pool.query(
        `SELECT i.interaction_type, i.created_at, i.post_id, u.username AS post_author
         FROM interactions i
         JOIN posts p ON p.post_id = i.post_id
         JOIN users u ON u.user_id = p.user_id
         WHERE i.user_id = ?
         ORDER BY i.created_at DESC LIMIT 10`,
        [id]
      )
    ]);

    if (!profile[0].length) return res.status(404).json({ error: 'No user with that id' });
    res.json({ profile: profile[0][0], topPosts: posts[0], recentActivity: recent[0] });
  })
);

// ----------------------------------------------------------------- posts ---
router.get(
  '/posts',
  wrap(async (req, res) => {
    const search = (req.query.search || '').trim();
    const type = ['text', 'image', 'video', 'link'].includes(req.query.type) ? req.query.type : '';
    const limit = Math.min(Number(req.query.limit) || 25, 100);

    const [rows] = await pool.query(
      `SELECT pe.post_id, pe.author, pe.topic, pe.post_type, LEFT(p.content, 90) AS preview,
              DATE(pe.posted_at) AS posted_on, pe.likes, pe.comments, pe.shares,
              pe.views, pe.engagement_score
       FROM v_post_engagement pe
       JOIN posts p ON p.post_id = pe.post_id
       WHERE (? = '' OR p.topic LIKE CONCAT('%', ?, '%') OR p.content LIKE CONCAT('%', ?, '%'))
         AND (? = '' OR pe.post_type = ?)
       ORDER BY pe.engagement_score DESC
       LIMIT ?`,
      [search, search, search, type, type, limit]
    );
    res.json(rows);
  })
);

// ------------------------------------------------------------- query lab ---
router.get('/queries', (_req, res) => res.json(listQueries()));

router.post(
  '/queries/:id/run',
  wrap(async (req, res) => {
    const query = getQuery(req.params.id);
    if (!query) return res.status(404).json({ error: 'No query with that id' });

    const { rows, fields, elapsedMs } = await timedQuery(query.sql);
    res.json({
      id: query.id,
      title: query.title,
      sql: query.sql,
      fields,
      rows,
      rowCount: rows.length,
      elapsedMs: Number(elapsedMs.toFixed(2))
    });
  })
);

// A deliberately narrow door for user written SQL: read only transaction,
// single statement, SELECT or WITH only, and a hard statement timeout.
const BLOCKED = /\b(insert|update|delete|drop|alter|create|truncate|grant|revoke|copy|vacuum|reindex|call|do|set|begin|commit|rollback)\b/i;

router.post(
  '/sql',
  wrap(async (req, res) => {
    if (!ALLOW_CUSTOM_SQL) return res.status(403).json({ error: 'The SQL console is switched off on this deployment' });

    const raw = String(req.body.sql || '').trim().replace(/;+\s*$/, '');
    if (!raw) return res.status(400).json({ error: 'Type a query first' });
    if (raw.includes(';')) return res.status(400).json({ error: 'Run one statement at a time' });
    if (!/^(select|with)\b/i.test(raw)) return res.status(400).json({ error: 'Only SELECT and WITH queries can run here' });
    if (BLOCKED.test(raw)) return res.status(400).json({ error: 'This console is read only, so that keyword is not allowed' });

    const connection = await pool.getConnection();
    try {
      // read-only transaction plus a hard time limit, so a runaway query
      // cannot hold the server up or change anything
      await connection.query('START TRANSACTION READ ONLY');
      const seconds = Math.max(1, parseInt(STATEMENT_TIMEOUT, 10) || 8);
      await connection.query(`SET SESSION MAX_EXECUTION_TIME = ${seconds * 1000}`);
      const started = process.hrtime.bigint();
      const [rows, fields] = await connection.query(`SELECT * FROM (${raw}) AS user_query LIMIT 200`);
      const elapsedMs = Number(process.hrtime.bigint() - started) / 1e6;
      await connection.query('ROLLBACK');
      res.json({
        fields: (fields || []).map((f) => f.name),
        rows,
        rowCount: rows.length,
        elapsedMs: Number(elapsedMs.toFixed(2)),
        truncated: rows.length === 200
      });
    } catch (err) {
      await connection.query('ROLLBACK').catch(() => {});
      res.status(400).json({ error: err.message });
    } finally {
      connection.release();
    }
  })
);


// ------------------------------------------------- stored programs & CRUD ---
// Everything below exercises the database's own procedural code: two
// functions, two cursor procedures and three triggers.

router.get(
  '/programs',
  wrap(async (_req, res) => {
    const [routines] = await pool.query(
      `SELECT routine_type AS kind, routine_name AS name
       FROM information_schema.routines WHERE routine_schema = DATABASE()
       ORDER BY routine_type, routine_name`
    );
    const [triggers] = await pool.query(
      `SELECT trigger_name AS name, event_manipulation AS event,
              event_object_table AS on_table, action_timing AS timing
       FROM information_schema.triggers WHERE trigger_schema = DATABASE()
       ORDER BY event_object_table, trigger_name`
    );
    res.json({ routines, triggers });
  })
);

/** Function 1: the weighted score for one post. */
router.get(
  '/functions/post/:id',
  wrap(async (req, res) => {
    const [rows] = await pool.query(
      `SELECT p.post_id, p.topic, u.username AS author,
              CalculatePostEngagement(p.post_id) AS points_from_function,
              v.engagement_score AS points_from_view
       FROM posts p
       JOIN users u ON u.user_id = p.user_id
       JOIN v_post_engagement v ON v.post_id = p.post_id
       WHERE p.post_id = ?`,
      [Number(req.params.id)]
    );
    if (!rows.length) return res.status(404).json({ error: 'No post with that id' });
    res.json(rows[0]);
  })
);

/** Function 2: everything one creator has earned. */
router.get(
  '/functions/user/:id',
  wrap(async (req, res) => {
    const [rows] = await pool.query(
      `SELECT u.user_id, u.username,
              CalculateUserEngagement(u.user_id) AS points_from_function,
              (SELECT COUNT(*) FROM posts p WHERE p.user_id = u.user_id) AS posts
       FROM users u WHERE u.user_id = ?`,
      [Number(req.params.id)]
    );
    if (!rows.length) return res.status(404).json({ error: 'No user with that id' });
    res.json(rows[0]);
  })
);

/** Procedure 1: cursor over one creator's posts. */
router.post(
  '/procedures/user-report',
  wrap(async (req, res) => {
    const userId = Number(req.body.userId);
    if (!Number.isInteger(userId)) return res.status(400).json({ error: 'userId must be a number' });
    const started = process.hrtime.bigint();
    const [result] = await pool.query('CALL GenerateUserEngagementReport(?)', [userId]);
    const elapsedMs = Number(process.hrtime.bigint() - started) / 1e6;
    res.json({ rows: result[0] || [], elapsedMs: Number(elapsedMs.toFixed(2)) });
  })
);

/** Procedure 2: cursor over every post in a date window. */
router.post(
  '/procedures/trending-report',
  wrap(async (req, res) => {
    const days = Math.min(Math.max(Number(req.body.days) || 14, 1), 180);
    const limit = Math.min(Math.max(Number(req.body.limit) || 10, 1), 50);
    const started = process.hrtime.bigint();
    const [result] = await pool.query(
      'CALL GenerateTrendingPostReport(NOW() - INTERVAL ? DAY, NOW(), ?)',
      [days, limit]
    );
    const elapsedMs = Number(process.hrtime.bigint() - started) / 1e6;
    res.json({ rows: result[0] || [], days, elapsedMs: Number(elapsedMs.toFixed(2)) });
  })
);

/** The audit trail written by the triggers. */
router.get(
  '/audit',
  wrap(async (_req, res) => {
    const [interactions] = await pool.query(
      `SELECT a.audit_id, a.post_id, a.user_id, u.username, a.interaction_type, a.action, a.recorded_at
       FROM interaction_audit a
       LEFT JOIN users u ON u.user_id = a.user_id
       ORDER BY a.audit_id DESC LIMIT 15`
    );
    const [posts] = await pool.query(
      'SELECT audit_id, post_id, user_id, topic, action, recorded_at FROM post_audit ORDER BY audit_id DESC LIMIT 15'
    );
    res.json({ interactions, posts });
  })
);

// ---- CRUD: create a post, record an interaction, delete a post ----

router.post(
  '/posts',
  wrap(async (req, res) => {
    const userId = Number(req.body.userId);
    const topic = String(req.body.topic || '').trim().slice(0, 60);
    const content = String(req.body.content || '').trim().slice(0, 500);
    const postType = ['text', 'image', 'video', 'link'].includes(req.body.postType) ? req.body.postType : 'text';
    if (!Number.isInteger(userId) || !topic || !content) {
      return res.status(400).json({ error: 'userId, topic and content are all required' });
    }
    const [result] = await pool.query(
      'INSERT INTO posts (user_id, content, topic, post_type, created_at) VALUES (?, ?, ?, ?, NOW())',
      [userId, content, topic, postType]
    );
    res.status(201).json({ post_id: result.insertId, topic, postType });
  })
);

router.post(
  '/interactions',
  wrap(async (req, res) => {
    const postId = Number(req.body.postId);
    const userId = Number(req.body.userId);
    const type = ['like', 'share', 'save', 'view'].includes(req.body.type) ? req.body.type : 'like';
    if (!Number.isInteger(postId) || !Number.isInteger(userId)) {
      return res.status(400).json({ error: 'postId and userId must be numbers' });
    }
    try {
      const [result] = await pool.query(
        'INSERT INTO interactions (post_id, user_id, interaction_type, created_at) VALUES (?, ?, ?, NOW())',
        [postId, userId, type]
      );
      const [score] = await pool.query('SELECT CalculatePostEngagement(?) AS points', [postId]);
      res.status(201).json({ interaction_id: result.insertId, type, points: score[0].points });
    } catch (err) {
      // the triggers and constraints speak for themselves, so pass their message on
      res.status(400).json({ error: err.sqlMessage || err.message });
    }
  })
);

router.delete(
  '/posts/:id',
  wrap(async (req, res) => {
    const [result] = await pool.query('DELETE FROM posts WHERE post_id = ?', [Number(req.params.id)]);
    if (!result.affectedRows) return res.status(404).json({ error: 'No post with that id' });
    const [audit] = await pool.query('SELECT * FROM post_audit ORDER BY audit_id DESC LIMIT 1');
    res.json({ deleted: Number(req.params.id), auditRow: audit[0] || null });
  })
);

// ------------------------------------------------------------- index lab ---
router.get(
  '/indexes',
  wrap(async (_req, res) => {
    const [rows] = await pool.query(`
      SELECT s.index_name  AS indexname,
             s.table_name  AS tablename,
             GROUP_CONCAT(s.column_name ORDER BY s.seq_in_index) AS columns,
             MAX(s.non_unique) = 0 AS is_unique
      FROM information_schema.statistics s
      WHERE s.table_schema = DATABASE()
      GROUP BY s.index_name, s.table_name
      ORDER BY (s.index_name LIKE 'idx%') DESC, s.table_name, s.index_name
    `);
    const present = await listPresent(pool);
    res.json({
      enabled: present.length > 0,
      secondaryCount: present.length,
      // InnoDB indexes every foreign key itself, which is why the list is
      // longer than the nine indexes this project creates
      totalIndexes: rows.length,
      indexes: rows.map((r) => ({
        indexname: r.indexname,
        tablename: r.tablename,
        definition: `(${r.columns})${Number(r.is_unique) ? ' UNIQUE' : ''}`,
        created_by: String(r.indexname).startsWith('idx_') ? 'this project' : 'primary key, unique or foreign key'
      })),
      catalog: INDEXES
    });
  })
);

router.post(
  '/indexes/:action',
  wrap(async (req, res) => {
    const { action } = req.params;
    if (!['enable', 'disable'].includes(action)) {
      return res.status(400).json({ error: 'action must be enable or disable' });
    }
    const started = Date.now();
    if (action === 'enable') await createAll(pool);
    else await dropAll(pool);
    const present = await listPresent(pool);
    res.json({ enabled: present.length > 0, secondaryCount: present.length, tookMs: Date.now() - started });
  })
);

// ------------------------------------------------------------- benchmark ---
/**
 * MySQL only gained EXPLAIN ANALYZE in 8.0.18, so the timing is taken here,
 * around the query itself. EXPLAIN reports which access method the optimiser
 * picked: ALL means a full table scan, ref and range mean an index was used.
 */
async function explainAccess(sql) {
  const [rows] = await pool.query(`EXPLAIN ${sql.replace(/;\s*$/, '')}`);
  return rows.map((r) => ({
    table: r.table,
    type: r.type,
    key: r.key,
    rows: r.rows,
    usesIndex: Boolean(r.key)
  }));
}

router.post(
  '/benchmark',
  wrap(async (req, res) => {
    const query = getQuery(req.body.queryId);
    if (!query) return res.status(404).json({ error: 'No query with that id' });
    const runs = Math.min(Math.max(Number(req.body.runs) || 3, 1), 5);

    const times = [];
    for (let i = 0; i < runs; i++) {
      const { elapsedMs } = await timedQuery(query.sql);
      times.push(elapsedMs);
    }
    const present = await listPresent(pool);

    res.json({
      queryId: query.id,
      title: query.title,
      runs,
      indexesEnabled: present.length > 0,
      secondaryCount: present.length,
      best: Number(Math.min(...times).toFixed(2)),
      worst: Number(Math.max(...times).toFixed(2)),
      average: Number((times.reduce((a, b) => a + b, 0) / times.length).toFixed(2)),
      access: await explainAccess(query.sql)
    });
  })
);

// ---------------------------------------------------------------- schema ---
router.get(
  '/schema',
  wrap(async (_req, res) => {
    const [columns, constraints, counts] = await Promise.all([
      pool.query(`
        SELECT table_name AS table_name, column_name AS column_name,
               column_type AS data_type, is_nullable AS is_nullable, ordinal_position AS ordinal_position
        FROM information_schema.columns
        WHERE table_schema = DATABASE()
          AND table_name IN ('users','posts','comments','followers','interactions')
        ORDER BY table_name, ordinal_position
      `),
      pool.query(`
        SELECT tc.table_name AS table_name, tc.constraint_type AS constraint_type,
               tc.constraint_name AS constraint_name, kcu.column_name AS column_name,
               kcu.referenced_table_name AS references_table
        FROM information_schema.table_constraints tc
        LEFT JOIN information_schema.key_column_usage kcu
               ON kcu.constraint_name = tc.constraint_name
              AND kcu.table_schema = tc.table_schema
              AND kcu.table_name = tc.table_name
        WHERE tc.table_schema = DATABASE()
          AND tc.table_name IN ('users','posts','comments','followers','interactions')
        ORDER BY tc.table_name, tc.constraint_type
      `),
      pool.query(`
        SELECT table_name AS table_name, table_rows AS approx_rows
        FROM information_schema.tables
        WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'
        ORDER BY table_rows DESC
      `)
    ]);
    res.json({ columns: columns[0], constraints: constraints[0], counts: counts[0] });
  })
);

module.exports = router;
