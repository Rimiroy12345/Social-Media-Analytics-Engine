'use strict';

/**
 * First-run setup.
 *
 * A fresh deployment points at an empty database. Rather than making someone
 * run migrations by hand, the server checks on startup and builds whatever is
 * missing: tables, views, indexes, then the dataset.
 *
 * Safe to run every boot. Existing data is left alone.
 * Set AUTO_SETUP=false to manage the schema yourself.
 */

const fs = require('fs');
const path = require('path');
const { pool, describeTarget } = require('./pool');
const { seedDatabase } = require('./seed');
const { createAll } = require('./indexes');

const read = (file) => fs.readFileSync(path.join(__dirname, file), 'utf8');
const statements = (sql) =>
  sql
    .split(/;\s*$/m)
    .map((part) => part.replace(/^\s*--.*$/gm, '').trim())
    .filter(Boolean);


/** programs.sql uses a custom delimiter so procedure bodies survive. */
function programBlocks(sql) {
  return sql
    .split('$$')
    .map((block) => block.replace(/^\s*DELIMITER.*$/gm, '').trim())
    .filter((block) => block && !/^(--[^\n]*\n?)+$/.test(block));
}

const status = {
  ready: false,
  phase: 'starting',
  message: 'connecting to MySQL',
  error: null,
  startedAt: Date.now(),
  finishedAt: null
};

const set = (phase, message) => {
  status.phase = phase;
  status.message = message;
  console.log(`[setup] ${message}`);
};

const getStatus = () => ({
  ...status,
  elapsedSeconds: Number((((status.finishedAt || Date.now()) - status.startedAt) / 1000).toFixed(1))
});

async function waitForDatabase(attempts = 10) {
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      await pool.query('SELECT 1');
      return;
    } catch (err) {
      // A wrong password or a missing database will never fix itself, so say
      // so immediately instead of retrying ten times.
      if (['ER_ACCESS_DENIED_ERROR', 'ER_BAD_DB_ERROR', 'ER_DBACCESS_DENIED_ERROR'].includes(err.code)) {
        throw new Error(`${err.sqlMessage || err.message} — check DB_USER, DB_PASSWORD and DB_NAME in your .env (using ${describeTarget()})`);
      }
      if (attempt === attempts) throw new Error(`${err.message} (tried ${describeTarget()})`);
      set('waiting', `MySQL not reachable yet, retrying (${attempt}/${attempts})`);
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }
}

async function ensureDatabase() {
  try {
    await waitForDatabase();
    const connection = await pool.getConnection();
    try {
      const [existing] = await connection.query(
        "SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'users'"
      );

      if (existing[0].n === 0) {
        if (process.env.AUTO_SETUP === 'false') {
          throw new Error('No tables found and AUTO_SETUP is off. Run: npm run db:reset');
        }
        set('schema', 'creating tables');
        for (const statement of statements(read('schema.sql'))) await connection.query(statement);
      }

      set('views', 'creating views');
      for (const statement of statements(read('views.sql'))) await connection.query(statement);

      set('indexes', 'creating indexes');
      await createAll(pool);

      const [counts] = await connection.query('SELECT COUNT(*) AS n FROM users');
      if (counts[0].n === 0) {
        if (process.env.AUTO_SETUP === 'false') {
          set('empty', 'tables are empty and AUTO_SETUP is off');
        } else {
          set('seeding', 'generating the dataset, this takes a few seconds');
          await seedDatabase(connection, (message) => set('seeding', message));
        }
      } else {
        set('ready', `found an existing dataset with ${counts[0].n.toLocaleString()} users`);
      }

      // Stored programs go in after the bulk load, the way a real deployment
      // would: no point running the audit trigger 177,000 times for seed data.
      set('programs', 'creating functions, procedures and triggers');
      for (const block of programBlocks(read('programs.sql'))) await connection.query(block);
    } finally {
      connection.release();
    }

    status.ready = true;
    status.finishedAt = Date.now();
    set('ready', `database ready in ${getStatus().elapsedSeconds} s`);
  } catch (err) {
    status.error = err.message;
    status.finishedAt = Date.now();
    set('failed', `setup failed: ${err.message}`);
  }
}

module.exports = { ensureDatabase, getStatus };
