'use strict';

/**
 * Generates a realistic, skewed dataset.
 *
 * Nothing here is uniformly random. A handful of users attract most of the
 * followers, a handful of posts go viral, and activity rises towards the
 * present day. That skew is what makes RANK(), moving averages and
 * "above the author's average" queries produce interesting answers.
 *
 * Volume is configurable:
 *   SEED_USERS=600 SEED_POSTS=6000 SEED_INTERACTIONS=180000 npm run db:seed
 */

const { pool } = require('./pool');

const CONFIG = {
  users: Number(process.env.SEED_USERS || 600),
  posts: Number(process.env.SEED_POSTS || 6000),
  comments: Number(process.env.SEED_COMMENTS || 24000),
  follows: Number(process.env.SEED_FOLLOWS || 14000),
  interactions: Number(process.env.SEED_INTERACTIONS || 180000),
  days: Number(process.env.SEED_DAYS || 180)
};

// ---- deterministic pseudo random number generator -------------------------
let state = Number(process.env.SEED_RANDOM || 20260921) % 2147483647;
if (state <= 0) state += 2147483646;
const rand = () => ((state = (state * 16807) % 2147483647) - 1) / 2147483646;
const randInt = (min, max) => min + Math.floor(rand() * (max - min + 1));
const pick = (arr) => arr[Math.floor(rand() * arr.length)];

// ---- vocabulary -----------------------------------------------------------
const FIRST = ['Aarav','Isha','Rohan','Meera','Kabir','Ananya','Vikram','Sana','Devan','Priya','Arjun','Nisha','Omar','Leila','Mateo','Sofia','Chen','Yuki','Amara','Tomas','Nora','Elias','Farah','Jonas','Ivy','Rafael','Zara','Noah','Lina','Hugo','Divya','Samir','Tara','Ewan','Maya','Idris','Clara','Ravi','Emma','Lucas'];
const LAST = ['Shah','Iyer','Nair','Verma','Kulkarni','Deshmukh','Bose','Rao','Khan','Mehta','Silva','Costa','Rossi','Fischer','Nakamura','Park','Okafor','Haddad','Novak','Berg','Lindqvist','Moreau','Dubois','Walsh','Osei','Reyes','Tan','Petrov','Kaur','Joshi'];
const COUNTRIES = ['India','United States','Brazil','Germany','Japan','Nigeria','United Kingdom','Canada','Spain','Indonesia','Australia','France'];
const POST_TYPES = ['text', 'image', 'video', 'link'];
// Formats do not perform equally - video and image travel further.
const TYPE_REACH = { video: 1.5, image: 1.2, link: 0.85, text: 0.75 };
const TOPICS = ['campus life','late night debugging','filter coffee','monsoon photography','a half finished side project','exam week','street food maps','open source','my first internship','budget travel','the hostel wifi','database theory','film photography','home cooking','morning runs','second hand bookshops','indie games','learning guitar','plant care','city cycling'];
const OPENERS = ['Finally shipped','Three weeks into','Unpopular opinion about','Everything I learned from','A small update on','Some notes on','Why I stopped worrying about','The honest version of','Day 40 of','Rethinking'];
const CLOSERS = ['Not sure how I feel about it yet.','Would do it again.','Sharing in case it helps someone.','Comments welcome.','Long post, sorry.','Photos in the thread.','Still figuring it out.','Turned out better than expected.'];
const COMMENT_LINES = ['This is really useful, thanks for writing it up.','How long did this take you?','Saving this for later.','Completely disagree, but I see your point.','Same experience here last semester.','Any chance you can share the source?','The second point is the one that got me.','Underrated take.','Following for part two.','Tried this yesterday, it works.','Where did you shoot this?','What setup are you using?'];

// weights: views dominate, shares are rare - matches real platforms
const TYPE_BUCKETS = [
  ['view', 0.55],
  ['like', 0.3],
  ['save', 0.08],
  ['share', 0.07]
];
const pickType = () => {
  let r = rand();
  for (const [type, weight] of TYPE_BUCKETS) {
    if (r < weight) return type;
    r -= weight;
  }
  return 'view';
};

const now = Date.now();
const DAY = 86400000;
/** MySQL DATETIME literal. */
const stamp = (ms) => new Date(ms).toISOString().slice(0, 19).replace('T', ' ');
/** Recent days are a little more likely than old ones. */
const skewedPastDate = (maxDaysAgo, skew = 1.15) => {
  const daysAgo = maxDaysAgo * Math.pow(rand(), skew);
  return stamp(now - daysAgo * DAY - randInt(0, 86399) * 1000);
};

// ---- batched insert helper ------------------------------------------------
/**
 * mysql2 expands a single ? into a whole VALUES list, so a few thousand rows
 * travel as one statement instead of one round trip per row.
 */
async function insertBatch(client, table, columns, rows, { ignore = false } = {}) {
  const size = 2000;
  const verb = ignore ? 'INSERT IGNORE INTO' : 'INSERT INTO';
  for (let start = 0; start < rows.length; start += size) {
    const chunk = rows.slice(start, start + size);
    await client.query(`${verb} ${table} (${columns.join(',')}) VALUES ?`, [chunk]);
  }
}

/**
 * Fills an empty database.
 * @param {import('pg').PoolClient} client an open client
 * @param {(message: string) => void} [report] called as each stage completes
 */
async function seedDatabase(client, report = () => {}) {
  const progress = (label, n) => report(`${label}: ${n.toLocaleString()} rows`);
  const startedAt = Date.now();
  {
    report('clearing existing rows');
    await client.query('SET FOREIGN_KEY_CHECKS = 0');
    for (const table of ['interactions', 'comments', 'followers', 'posts', 'users']) {
      await client.query(`TRUNCATE TABLE ${table}`);
    }
    await client.query('SET FOREIGN_KEY_CHECKS = 1');

    // ---------- users ----------
    const users = [];
    const seenNames = new Set();
    for (let i = 1; i <= CONFIG.users; i++) {
      const first = pick(FIRST);
      const last = pick(LAST);
      let username = `${first}${last}${randInt(1, 999)}`.toLowerCase();
      while (seenNames.has(username)) username = `${first}${last}${randInt(1, 99999)}`.toLowerCase();
      seenNames.add(username);
      users.push({
        id: i,
        username,
        fullName: `${first} ${last}`,
        email: `${username}@example.com`,
        bio: `${pick(['Writes about','Posting mostly about','Here for'])} ${pick(TOPICS)}.`,
        country: pick(COUNTRIES),
        createdAt: skewedPastDate(CONFIG.days * 2),
        // influence follows a cube curve: most users are ordinary, a few are not
        influence: Math.pow(rand(), 3),
        // ~7% register and then never engage with anything - real platforms
        // are full of them, and the NOT EXISTS query needs them to exist
        silent: rand() < 0.07
      });
    }
    await insertBatch(
      client,
      'users',
      ['username', 'full_name', 'email', 'bio', 'country', 'created_at'],
      users.map((u) => [u.username, u.fullName, u.email, u.bio, u.country, u.createdAt])
    );
    progress('users', users.length);

    // Everyone except the silent accounts can generate engagement.
    const activeUsers = users.filter((u) => !u.silent);

    // Weighted picker so popular users get more of everything.
    const weights = users.map((u) => 0.15 + u.influence * 4);
    const totalWeight = weights.reduce((a, b) => a + b, 0);
    const pickUser = () => {
      let r = rand() * totalWeight;
      for (let i = 0; i < weights.length; i++) {
        r -= weights[i];
        if (r <= 0) return users[i];
      }
      return users[users.length - 1];
    };

    // ---------- posts ----------
    const posts = [];
    for (let i = 1; i <= CONFIG.posts; i++) {
      const author = pickUser();
      const createdAt = skewedPastDate(CONFIG.days);
      const type = pick(POST_TYPES);
      const topic = pick(TOPICS);
      posts.push({
        id: i,
        userId: author.id,
        content: `${pick(OPENERS)} ${topic}. ${pick(CLOSERS)}`,
        topic,
        type,
        createdAt,
        // a post's reach: the format, the author's influence, and its own luck
        reach: (0.1 + author.influence * 2 + Math.pow(rand(), 4) * 3) * TYPE_REACH[type]
      });
    }
    await insertBatch(
      client,
      'posts',
      ['user_id', 'content', 'topic', 'post_type', 'created_at'],
      posts.map((p) => [p.userId, p.content, p.topic, p.type, p.createdAt])
    );
    progress('posts', posts.length);

    // ---------- followers ----------
    const followPairs = new Set();
    const followRows = [];
    let guard = 0;
    while (followRows.length < CONFIG.follows && guard < CONFIG.follows * 12) {
      guard++;
      const follower = users[randInt(0, users.length - 1)];
      const followee = pickUser();
      if (follower.id === followee.id) continue;
      const key = `${follower.id}:${followee.id}`;
      if (followPairs.has(key)) continue;
      followPairs.add(key);
      followRows.push([follower.id, followee.id, skewedPastDate(CONFIG.days)]);
    }
    await insertBatch(client, 'followers', ['follower_id', 'followee_id', 'followed_at'], followRows, { ignore: true });
    progress('followers', followRows.length);

    // Post picker weighted by reach, so a few posts collect most engagement.
    const postWeights = posts.map((p) => p.reach);
    const postTotal = postWeights.reduce((a, b) => a + b, 0);
    const pickPost = () => {
      let r = rand() * postTotal;
      for (let i = 0; i < postWeights.length; i++) {
        r -= postWeights[i];
        if (r <= 0) return posts[i];
      }
      return posts[posts.length - 1];
    };

    /** An event on a post always happens after the post was published. */
    const afterPost = (post) => {
      const publishedMs = Date.parse(post.createdAt.replace(' ', 'T') + 'Z');
      const window = Math.max(now - publishedMs, 60000);
      // engagement clusters in the hours right after publishing
      return stamp(publishedMs + window * Math.pow(rand(), 3));
    };

    // ---------- comments ----------
    const commentRows = [];
    for (let i = 0; i < CONFIG.comments; i++) {
      const post = pickPost();
      const commenter = activeUsers[randInt(0, activeUsers.length - 1)];
      commentRows.push([post.id, commenter.id, pick(COMMENT_LINES), afterPost(post)]);
    }
    await insertBatch(client, 'comments', ['post_id', 'user_id', 'content', 'created_at'], commentRows);
    progress('comments', commentRows.length);

    // ---------- interactions ----------
    let written = 0;
    const seenInteractions = new Set();
    const buffer = [];
    for (let i = 0; i < CONFIG.interactions; i++) {
      const post = pickPost();
      const user = activeUsers[randInt(0, activeUsers.length - 1)];
      // nobody engages with their own post - the trg_no_self_engagement
      // trigger enforces this, so the generated data has to respect it too
      if (user.id === post.userId) continue;
      const type = pickType();
      const key = `${post.id}:${user.id}:${type}`;
      if (seenInteractions.has(key)) continue;
      seenInteractions.add(key);
      buffer.push([post.id, user.id, type, afterPost(post)]);
      if (buffer.length >= 5000) {
        await insertBatch(client, 'interactions', ['post_id', 'user_id', 'interaction_type', 'created_at'], buffer, { ignore: true });
        written += buffer.length;
        buffer.length = 0;
        report(`interactions: ${written.toLocaleString()} rows`);
      }
    }
    if (buffer.length) {
      await insertBatch(client, 'interactions', ['post_id', 'user_id', 'interaction_type', 'created_at'], buffer, { ignore: true });
      written += buffer.length;
    }
    progress('interactions', written);

    report('refreshing optimiser statistics');
    for (const table of ['users', 'posts', 'comments', 'followers', 'interactions']) {
      await client.query(`ANALYZE TABLE ${table}`);
    }

    const [rows] = await client.query(`
      SELECT
        (SELECT COUNT(*) FROM users)        AS users,
        (SELECT COUNT(*) FROM posts)        AS posts,
        (SELECT COUNT(*) FROM comments)     AS comments,
        (SELECT COUNT(*) FROM followers)    AS followers,
        (SELECT COUNT(*) FROM interactions) AS interactions
    `);
    const seconds = ((Date.now() - startedAt) / 1000).toFixed(1);
    report(`finished in ${seconds} seconds`);
    return { ...rows[0], seconds };
  }
}

module.exports = { seedDatabase, CONFIG };

// Running this file directly seeds the database from the command line.
if (require.main === module) {
  (async () => {
    const client = await pool.getConnection();
    try {
      const totals = await seedDatabase(client, (message) => console.log(' ', message));
      console.table(totals);
    } finally {
      client.release();
      await pool.end();
    }
  })().catch((err) => {
    console.error('\nSeeding failed:', err.message);
    process.exit(1);
  });
}
