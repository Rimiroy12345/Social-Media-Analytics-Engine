-- ============================================================
--  Analytical views
--  Points: view 0.2, like 1, save 2, comment 2, share 3
--
--  MySQL has no FILTER (WHERE ...) clause, so conditional counts
--  are written as SUM(CASE WHEN ... THEN 1 ELSE 0 END).
-- ============================================================

DROP VIEW IF EXISTS v_daily_engagement;
DROP VIEW IF EXISTS v_user_engagement;
DROP VIEW IF EXISTS v_post_engagement;

-- One row per post, with every engagement metric derived on the fly.
-- Comments are counted with a subquery rather than a second join, so the
-- two joins cannot multiply each other's rows.
CREATE VIEW v_post_engagement AS
SELECT p.post_id,
       p.user_id AS author_id,
       u.username AS author,
       p.topic,
       p.post_type,
       p.created_at AS posted_at,
       SUM(CASE WHEN i.interaction_type = 'like' THEN 1 ELSE 0 END) AS likes,
       SUM(CASE WHEN i.interaction_type = 'share' THEN 1 ELSE 0 END) AS shares,
       SUM(CASE WHEN i.interaction_type = 'save' THEN 1 ELSE 0 END) AS saves,
       SUM(CASE WHEN i.interaction_type = 'view' THEN 1 ELSE 0 END) AS views,
       (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.post_id) AS comments,
       COUNT(i.interaction_id) AS total_interactions,
       COUNT(DISTINCT i.user_id) AS unique_engagers,
       MAX(i.created_at) AS last_interaction_at,
       ROUND(SUM(CASE WHEN i.interaction_type = 'view' THEN 0.2
                      WHEN i.interaction_type = 'like' THEN 1.0
                      WHEN i.interaction_type = 'save' THEN 2.0
                      WHEN i.interaction_type = 'share' THEN 3.0
                      ELSE 0 END)
             + (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.post_id) * 2.0, 1) AS engagement_score
FROM posts p
JOIN users u ON u.user_id = p.user_id
LEFT JOIN interactions i ON i.post_id = p.post_id
GROUP BY p.post_id, p.user_id, u.username, p.topic, p.post_type, p.created_at;

-- One row per user: what they publish and how well it lands.
CREATE VIEW v_user_engagement AS
SELECT u.user_id,
       u.username,
       u.full_name,
       u.country,
       u.created_at AS joined_at,
       COUNT(pe.post_id) AS posts,
       COALESCE(SUM(pe.engagement_score), 0) AS engagement_score,
       ROUND(COALESCE(AVG(pe.engagement_score), 0), 1) AS avg_score_per_post,
       COALESCE(SUM(pe.likes), 0) AS likes_received,
       COALESCE(SUM(pe.comments), 0) AS comments_received,
       (SELECT COUNT(*) FROM followers f WHERE f.followee_id = u.user_id) AS followers,
       (SELECT COUNT(*) FROM followers f WHERE f.follower_id = u.user_id) AS following
FROM users u
LEFT JOIN v_post_engagement pe ON pe.author_id = u.user_id
GROUP BY u.user_id, u.username, u.full_name, u.country, u.created_at;

-- One row per calendar day of platform activity.
CREATE VIEW v_daily_engagement AS
SELECT DATE(created_at) AS activity_date,
       COUNT(*) AS interactions,
       SUM(CASE WHEN interaction_type = 'like' THEN 1 ELSE 0 END) AS likes,
       SUM(CASE WHEN interaction_type = 'share' THEN 1 ELSE 0 END) AS shares,
       SUM(CASE WHEN interaction_type = 'save' THEN 1 ELSE 0 END) AS saves,
       SUM(CASE WHEN interaction_type = 'view' THEN 1 ELSE 0 END) AS views,
       COUNT(DISTINCT user_id) AS active_users,
       COUNT(DISTINCT post_id) AS posts_touched
FROM interactions
GROUP BY DATE(created_at);
