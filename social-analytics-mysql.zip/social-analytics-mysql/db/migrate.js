'use strict';

/**
 * Creates the database objects.
 *   node db/migrate.js            -> create anything that is missing
 *   node db/migrate.js --fresh    -> drop every table first, then create
 */

const fs = require('fs');
const path = require('path');
const { pool, describeTarget } = require('./pool');
const { createAll } = require('./indexes');

const fresh = process.argv.includes('--fresh');
const read = (file) => fs.readFileSync(path.join(__dirname, file), 'utf8');

/** mysql2 runs one statement per call, so files are split on semicolons. */
const statements = (sql) =>
  sql
    .split(/;\s*$/m)
    .map((part) => part.replace(/^\s*--.*$/gm, '').trim())
    .filter(Boolean);

async function runFile(connection, file) {
  for (const statement of statements(read(file))) await connection.query(statement);
}


/** programs.sql uses a custom delimiter so procedure bodies survive. */
function programBlocks(sql) {
  return sql
    .split('$$')
    .map((block) => block.replace(/^\s*DELIMITER.*$/gm, '').trim())
    .filter((block) => block && !/^(--[^\n]*\n?)+$/.test(block));
}

async function tableExists(connection, name) {
  const [rows] = await connection.query(
    'SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?',
    [name]
  );
  return rows[0].n > 0;
}

async function main() {
  console.log('Connecting to', describeTarget());
  const connection = await pool.getConnection();
  try {
    if (fresh) {
      process.stdout.write('Dropping existing objects... ');
      await connection.query('SET FOREIGN_KEY_CHECKS = 0');
      for (const view of ['v_daily_engagement', 'v_user_engagement', 'v_post_engagement']) {
        await connection.query(`DROP VIEW IF EXISTS ${view}`);
      }
      for (const table of ['interactions', 'comments', 'followers', 'posts', 'users']) {
        await connection.query(`DROP TABLE IF EXISTS ${table}`);
      }
      await connection.query('SET FOREIGN_KEY_CHECKS = 1');
      console.log('done');
    }

    if (await tableExists(connection, 'users')) {
      if (!fresh) console.log('Tables already exist, leaving them in place.');
    } else {
      process.stdout.write('Creating tables... ');
      await runFile(connection, 'schema.sql');
      console.log('done');
    }

    process.stdout.write('Creating views... ');
    await runFile(connection, 'views.sql');
    console.log('done');

    process.stdout.write('Creating indexes... ');
    await createAll(pool);
    console.log('done');

    process.stdout.write('Creating functions, procedures and triggers... ');
    for (const block of programBlocks(read('programs.sql'))) await connection.query(block);
    console.log('done');

    console.log('\nDatabase is ready. Next: npm run db:seed');
  } finally {
    connection.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error('\nMigration failed:', err.message);
  process.exit(1);
});
