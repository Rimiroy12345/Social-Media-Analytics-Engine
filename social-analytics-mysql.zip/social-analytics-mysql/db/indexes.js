'use strict';

/**
 * Secondary indexes.
 *
 * MySQL has no CREATE INDEX IF NOT EXISTS, so each index is defined here
 * and created only when information_schema says it is missing.
 *
 * Worth knowing for the report: InnoDB creates an index automatically for
 * every foreign key, so posts.user_id, comments.post_id, comments.user_id,
 * interactions.user_id and followers.followee_id are already indexed by the
 * constraints themselves. PostgreSQL does not do this. The indexes below are
 * therefore the ones a foreign key does NOT give you: the columns queries
 * filter, sort and group by.
 */

const INDEXES = [
  { name: 'idx_interactions_created_at', table: 'interactions', columns: '(created_at)',
    why: 'time window filters: "the last 7 days"' },
  { name: 'idx_interactions_type_created', table: 'interactions', columns: '(interaction_type, created_at)',
    why: 'reporting on one kind of action over a period' },
  { name: 'idx_posts_created_at', table: 'posts', columns: '(created_at)',
    why: 'most recent posts first' },
  { name: 'idx_posts_type', table: 'posts', columns: '(post_type)',
    why: 'grouping and filtering by format' },
  { name: 'idx_posts_topic', table: 'posts', columns: '(topic)',
    why: 'searching posts by subject' },
  { name: 'idx_comments_created_at', table: 'comments', columns: '(created_at)',
    why: 'recent comment activity' },
  { name: 'idx_followers_followed_at', table: 'followers', columns: '(followed_at)',
    why: 'follower growth over time' },
  { name: 'idx_users_country', table: 'users', columns: '(country)',
    why: 'grouping people by country' },
  { name: 'idx_users_created_at', table: 'users', columns: '(created_at)',
    why: 'sign-up date ordering' }
];

/**
 * Which of THIS project's indexes are currently in place.
 * Matching on the name list rather than an idx_ prefix, so an index created
 * elsewhere (the audit table has one) is never mistaken for one of ours.
 */
async function listPresent(pool) {
  const names = INDEXES.map((i) => i.name);
  const [rows] = await pool.query(
    `SELECT DISTINCT index_name AS name
     FROM information_schema.statistics
     WHERE table_schema = DATABASE() AND index_name IN (?)`,
    [names]
  );
  return rows.map((r) => r.name);
}

async function createAll(pool) {
  const present = new Set(await listPresent(pool));
  for (const index of INDEXES) {
    if (present.has(index.name)) continue;
    await pool.query(`CREATE INDEX ${index.name} ON ${index.table} ${index.columns}`);
  }
  await analyze(pool);
}

async function dropAll(pool) {
  const present = new Set(await listPresent(pool));
  for (const index of INDEXES) {
    if (!present.has(index.name)) continue;
    await pool.query(`DROP INDEX ${index.name} ON ${index.table}`);
  }
  await analyze(pool);
}

/** Refresh the optimiser's statistics so it plans against current data. */
async function analyze(pool) {
  for (const table of ['users', 'posts', 'comments', 'followers', 'interactions']) {
    await pool.query(`ANALYZE TABLE ${table}`);
  }
}

module.exports = { INDEXES, listPresent, createAll, dropAll, analyze };
