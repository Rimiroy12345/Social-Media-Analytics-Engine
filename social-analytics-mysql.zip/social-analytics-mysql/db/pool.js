'use strict';

require('dotenv').config();
const mysql = require('mysql2/promise');

/**
 * Connection settings come from either a single DATABASE_URL, or the
 * individual DB_ variables, whichever the environment provides.
 * XAMPP and a fresh MySQL install both work with the defaults below.
 */
const config = process.env.DATABASE_URL
  ? { uri: process.env.DATABASE_URL }
  : {
      host: process.env.DB_HOST || 'localhost',
      port: Number(process.env.DB_PORT || 3306),
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'social_analytics'
    };

const pool = mysql.createPool({
  ...config,
  waitForConnections: true,
  connectionLimit: Number(process.env.DB_POOL_MAX || 5),
  // MySQL returns DECIMAL and BIGINT as strings by default; numbers read better
  decimalNumbers: true,
  dateStrings: true,
  charset: 'utf8mb4'
});

/** Runs a query and reports how long MySQL took, in milliseconds. */
async function timedQuery(sql, params = []) {
  const started = process.hrtime.bigint();
  const [rows, fields] = await pool.query(sql, params);
  const elapsedMs = Number(process.hrtime.bigint() - started) / 1e6;
  return { rows, fields: (fields || []).map((f) => f.name), elapsedMs };
}

const describeTarget = () =>
  process.env.DATABASE_URL ? 'DATABASE_URL' : `${config.user}@${config.host}:${config.port}/${config.database}`;

module.exports = { pool, timedQuery, describeTarget };
