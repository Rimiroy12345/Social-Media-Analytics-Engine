-- ============================================================
--  Social Media Analytics Engine - relational schema
--  Target DBMS: MySQL 8.0 or newer
--
--  The schema is in 3NF. Every non-key attribute depends on the
--  whole primary key and nothing but the key. Engagement counts
--  are never stored on posts or users - they are always derived,
--  so the data cannot disagree with itself.
-- ============================================================

CREATE TABLE users (
    user_id    INT AUTO_INCREMENT PRIMARY KEY,
    username   VARCHAR(30)  NOT NULL UNIQUE,
    full_name  VARCHAR(80)  NOT NULL,
    email      VARCHAR(120) NOT NULL UNIQUE,
    bio        TEXT,
    country    VARCHAR(40)  NOT NULL,
    created_at DATETIME     NOT NULL,
    CONSTRAINT users_email_shape CHECK (email LIKE '%@%.%')
) ENGINE = InnoDB;

CREATE TABLE posts (
    post_id    INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT         NOT NULL,
    content    TEXT        NOT NULL,
    topic      VARCHAR(60) NOT NULL,
    post_type  VARCHAR(10) NOT NULL,
    created_at DATETIME    NOT NULL,
    CONSTRAINT posts_author_fk FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE,
    CONSTRAINT posts_type_allowed CHECK (post_type IN ('text', 'image', 'video', 'link'))
) ENGINE = InnoDB;

CREATE TABLE comments (
    comment_id INT AUTO_INCREMENT PRIMARY KEY,
    post_id    INT      NOT NULL,
    user_id    INT      NOT NULL,
    content    TEXT     NOT NULL,
    created_at DATETIME NOT NULL,
    CONSTRAINT comments_post_fk FOREIGN KEY (post_id) REFERENCES posts (post_id) ON DELETE CASCADE,
    CONSTRAINT comments_author_fk FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
) ENGINE = InnoDB;

-- Many-to-many relationship of users with themselves.
-- The composite primary key is what stops a duplicate follow.
CREATE TABLE followers (
    follower_id INT      NOT NULL,
    followee_id INT      NOT NULL,
    followed_at DATETIME NOT NULL,
    PRIMARY KEY (follower_id, followee_id),
    CONSTRAINT followers_follower_fk FOREIGN KEY (follower_id) REFERENCES users (user_id) ON DELETE CASCADE,
    CONSTRAINT followers_followee_fk FOREIGN KEY (followee_id) REFERENCES users (user_id) ON DELETE CASCADE,
    CONSTRAINT followers_no_self_follow CHECK (follower_id <> followee_id)
) ENGINE = InnoDB;

-- The high-volume fact table. One row per engagement event.
CREATE TABLE interactions (
    interaction_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    post_id        INT         NOT NULL,
    user_id        INT         NOT NULL,
    interaction_type VARCHAR(10) NOT NULL,
    created_at     DATETIME    NOT NULL,
    CONSTRAINT interactions_post_fk FOREIGN KEY (post_id) REFERENCES posts (post_id) ON DELETE CASCADE,
    CONSTRAINT interactions_user_fk FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE,
    CONSTRAINT interactions_type_allowed CHECK (interaction_type IN ('like', 'share', 'save', 'view')),
    CONSTRAINT interactions_one_per_user_per_type UNIQUE (post_id, user_id, interaction_type)
) ENGINE = InnoDB;
