/* ============================================================
   Social Media Analytics Engine — browser app
   No framework, no chart library. Charts are hand drawn SVG so the
   page works on a slow connection and nothing depends on a CDN.
   ============================================================ */

'use strict';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const escapeHtml = (value) =>
  String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const fmt = (value) => {
  if (value === null || value === undefined) return '—';
  if (typeof value === 'number') return Number.isInteger(value) ? value.toLocaleString() : value.toLocaleString(undefined, { maximumFractionDigits: 2 });
  if (typeof value === 'string' && /^-?\d+(\.\d+)?$/.test(value)) return Number(value).toLocaleString(undefined, { maximumFractionDigits: 2 });
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(value)) return value.slice(0, 16).replace('T', ' ');
  return String(value);
};

const isNumeric = (value) =>
  typeof value === 'number' || (typeof value === 'string' && value !== '' && /^-?\d+(\.\d+)?$/.test(value));

async function api(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const payload = await response.json().catch(() => ({ error: 'The server sent something that was not JSON' }));
  if (!response.ok) throw new Error(payload.error || `Request failed with ${response.status}`);
  return payload;
}

/** Builds a table from an array of plain objects. */
function table(rows, { columns, onRowClick, truncate = [] } = {}) {
  if (!rows || !rows.length) return '<p class="empty">Nothing to show.</p>';
  const keys = columns || Object.keys(rows[0]);
  const head = keys.map((k) => `<th class="${isNumeric(rows[0][k]) ? 'num' : ''}">${escapeHtml(k)}</th>`).join('');
  const body = rows
    .map((row, index) => {
      const cells = keys
        .map((k) => {
          const raw = row[k];
          const cls = isNumeric(raw) ? 'num' : '';
          const text = escapeHtml(fmt(raw));
          const content = truncate.includes(k) ? `<span class="truncate" title="${text}">${text}</span>` : text;
          return `<td class="${cls}">${content}</td>`;
        })
        .join('');
      return `<tr class="${onRowClick ? 'clickable' : ''}" data-index="${index}">${cells}</tr>`;
    })
    .join('');
  return `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
}

function wireRowClicks(container, rows, handler) {
  $$('tbody tr.clickable', container).forEach((tr) => {
    tr.addEventListener('click', () => handler(rows[Number(tr.dataset.index)]));
  });
}

/* ----------------------------------------------------------- charts --- */

/** Area + line chart with an optional dashed moving average. */
function lineChart(points, { width = 900, height = 230, yLabel = '' } = {}) {
  if (!points.length) return '<p class="empty">No activity in this window.</p>';
  const pad = { top: 14, right: 14, bottom: 26, left: 46 };
  const w = width - pad.left - pad.right;
  const h = height - pad.top - pad.bottom;
  const maxY = Math.max(...points.map((p) => Math.max(p.y, p.avg ?? 0))) * 1.1 || 1;
  const x = (i) => pad.left + (points.length === 1 ? w / 2 : (i / (points.length - 1)) * w);
  const y = (v) => pad.top + h - (v / maxY) * h;

  const path = points.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.y).toFixed(1)}`).join(' ');
  const area = `${path} L${x(points.length - 1).toFixed(1)},${pad.top + h} L${x(0).toFixed(1)},${pad.top + h} Z`;
  const avgPath = points
    .filter((p) => p.avg !== null && p.avg !== undefined)
    .map((p, i, arr) => `${i ? 'L' : 'M'}${x(points.indexOf(p)).toFixed(1)},${y(p.avg).toFixed(1)}`)
    .join(' ');

  const ticks = [0, 0.5, 1].map((f) => {
    const value = maxY * f;
    return `<line class="gridline" x1="${pad.left}" y1="${y(value)}" x2="${pad.left + w}" y2="${y(value)}" />
            <text class="tick" x="${pad.left - 6}" y="${y(value) + 3}" text-anchor="end">${Math.round(value).toLocaleString()}</text>`;
  });

  const step = Math.max(1, Math.round(points.length / 6));
  const xTicks = points
    .map((p, i) => (i % step === 0 || i === points.length - 1 ? `<text class="tick" x="${x(i)}" y="${height - 8}" text-anchor="middle">${escapeHtml(p.label)}</text>` : ''))
    .join('');

  return `<svg class="chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeHtml(yLabel || 'time series')}">
    ${ticks.join('')}
    <path class="series-area" d="${area}" />
    <path class="series-line" d="${path}" />
    ${avgPath ? `<path class="series-avg" d="${avgPath}" />` : ''}
    <line class="axis" x1="${pad.left}" y1="${pad.top + h}" x2="${pad.left + w}" y2="${pad.top + h}" />
    ${xTicks}
  </svg>`;
}

/** Horizontal comparison bars, used for benchmark timings. */
function barChart(items, { width = 760, barHeight = 34, unit = 'ms' } = {}) {
  if (!items.length) return '';
  const labelWidth = 150;
  const max = Math.max(...items.map((i) => i.value)) * 1.15 || 1;
  const height = items.length * barHeight + 10;
  const rows = items
    .map((item, index) => {
      const yPos = index * barHeight + 4;
      const barWidth = ((width - labelWidth - 90) * item.value) / max;
      return `<text class="bar-label" x="0" y="${yPos + 18}">${escapeHtml(item.label)}</text>
              <rect class="bar ${item.flag ? 'flag' : ''}" x="${labelWidth}" y="${yPos + 6}" width="${Math.max(barWidth, 1)}" height="16" rx="2" />
              <text class="bar-label" x="${labelWidth + Math.max(barWidth, 1) + 8}" y="${yPos + 18}">${item.value.toLocaleString(undefined, { maximumFractionDigits: 1 })} ${unit}</text>`;
    })
    .join('');
  return `<svg class="chart" viewBox="0 0 ${width} ${height}" role="img">${rows}</svg>`;
}

function barList(items) {
  const total = items.reduce((sum, i) => sum + i.value, 0) || 1;
  return `<div class="barlist">${items
    .map(
      (i) => `<div class="row">
        <span>${escapeHtml(i.label)}</span>
        <span class="track"><span class="fill" style="width:${((i.value / total) * 100).toFixed(1)}%"></span></span>
        <span class="value">${((i.value / total) * 100).toFixed(1)}%</span>
      </div>`
    )
    .join('')}</div>`;
}

/* -------------------------------------------------------- navigation -- */

const views = {};
function showView(name) {
  $$('.view').forEach((section) => {
    section.hidden = section.id !== `view-${name}`;
  });
  $$('#nav button').forEach((button) => button.setAttribute('aria-current', String(button.dataset.view === name)));
  if (views[name] && !views[name].loaded) {
    views[name].loaded = true;
    views[name].load();
  }
  if (location.hash !== `#${name}`) history.replaceState(null, '', `#${name}`);
}

$('#nav').addEventListener('click', (event) => {
  const button = event.target.closest('button[data-view]');
  if (button) showView(button.dataset.view);
});

/* ---------------------------------------------------------- overview -- */

views.overview = {
  loaded: false,
  async load() {
    try {
      const data = await api('/overview');
      const t = data.totals;

      // 7 day moving average computed in the browser to match the SQL version
      const daily = data.daily.map((row, index, all) => {
        const window = all.slice(Math.max(0, index - 6), index + 1);
        const avg = window.reduce((sum, r) => sum + Number(r.interactions), 0) / window.length;
        return {
          label: String(row.activity_date).slice(5, 10),
          y: Number(row.interactions),
          avg: Number(avg.toFixed(1))
        };
      });

      $('#dailyChart').innerHTML = lineChart(daily, { yLabel: 'daily interactions' });
      const busiest = data.daily.reduce((best, row) => (Number(row.interactions) > Number(best.interactions) ? row : best), data.daily[0]);
      $('#heroSummary').className = 'readout';
      $('#heroSummary').innerHTML = busiest
        ? `busiest day <strong>${String(busiest.activity_date).slice(0, 10)}</strong> with <strong>${Number(busiest.interactions).toLocaleString()}</strong> interactions`
        : '';

      $('#counts').innerHTML = [
        ['users', t.users],
        ['posts', t.posts],
        ['comments', t.comments],
        ['follow edges', t.follows],
        ['interactions', t.interactions],
        ['database size', t.database_size]
      ]
        .map(([label, value]) => `<div><dt>${label}</dt><dd>${fmt(value)}</dd></div>`)
        .join('');

      $('#topPosts').innerHTML = table(data.topPosts, {
        columns: ['post_id', 'author', 'preview', 'likes', 'comments', 'engagement_score'],
        truncate: ['preview']
      });
      $('#topUsers').innerHTML = table(data.topUsers, {
        columns: ['username', 'country', 'posts', 'followers', 'engagement_score']
      });
      $('#byType').innerHTML = table(data.byType);
      $('#mixBars').innerHTML = barList(data.mix.map((row) => ({ label: row.interaction_type, value: Number(row.n) })));

      $('#railFoot').innerHTML = `${fmt(t.interactions)} interactions<br />${fmt(t.posts)} posts<br />${t.database_size}<br />${String(t.first_activity).slice(0, 10)} → ${String(t.last_activity).slice(0, 10)}`;
    } catch (err) {
      $('#dailyChart').innerHTML = `<p class="error">${escapeHtml(err.message)}. Has the database been created and seeded yet?</p>`;
      $('#railFoot').textContent = 'no data';
    }
  }
};

/* ----------------------------------------------------------- explore -- */

async function loadUsers() {
  const search = $('#userSearch').value;
  const sort = $('#userSort').value;
  $('#userTable').innerHTML = '<p class="loading">running query…</p>';
  const rows = await api(`/users?search=${encodeURIComponent(search)}&sort=${sort}&limit=40`);
  $('#userTable').innerHTML = table(rows, {
    columns: ['user_id', 'username', 'country', 'posts', 'followers', 'following', 'engagement_score'],
    onRowClick: true
  });
  wireRowClicks($('#userTable'), rows, (row) => openUser(row.user_id));
}

async function loadPosts() {
  $('#postTable').innerHTML = '<p class="loading">running query…</p>';
  const rows = await api(`/posts?search=${encodeURIComponent($('#postSearch').value)}&type=${$('#postType').value}&limit=40`);
  $('#postTable').innerHTML = table(rows, {
    columns: ['post_id', 'author', 'post_type', 'preview', 'posted_on', 'likes', 'comments', 'shares', 'engagement_score'],
    truncate: ['preview']
  });
}

async function openUser(id) {
  const panel = $('#userDetail');
  panel.hidden = false;
  panel.innerHTML = '<p class="loading">loading profile…</p>';
  const { profile, topPosts, recentActivity } = await api(`/users/${id}`);
  panel.innerHTML = `
    <h2>${escapeHtml(profile.username)}</h2>
    <p class="sub">${escapeHtml(profile.full_name)} · ${escapeHtml(profile.country)} · joined ${String(profile.joined_at).slice(0, 10)}</p>
    <dl class="kv">
      <dt>posts</dt><dd>${fmt(profile.posts)}</dd>
      <dt>followers</dt><dd>${fmt(profile.followers)} (following ${fmt(profile.following)})</dd>
      <dt>engagement</dt><dd>${fmt(profile.engagement_score)} total, ${fmt(profile.avg_score_per_post)} per post</dd>
    </dl>
    <h3 style="margin-top:1rem">Best posts</h3>
    <div class="table-wrap">${table(topPosts)}</div>
    <h3 style="margin-top:1rem">Latest activity</h3>
    <div class="table-wrap">${table(recentActivity)}</div>
    <p style="margin-top:0.8rem"><button class="action quiet" id="closeUser">Close profile</button></p>`;
  $('#closeUser').addEventListener('click', () => {
    panel.hidden = true;
  });
  panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

views.explore = {
  loaded: false,
  load() {
    loadUsers().catch((err) => ($('#userTable').innerHTML = `<p class="error">${escapeHtml(err.message)}</p>`));
  }
};

$('#exploreTabs').addEventListener('click', (event) => {
  const button = event.target.closest('button[data-tab]');
  if (!button) return;
  $$('#exploreTabs button').forEach((b) => b.setAttribute('aria-selected', String(b === button)));
  const showUsers = button.dataset.tab === 'users';
  $('#usersPanel').hidden = !showUsers;
  $('#postsPanel').hidden = showUsers;
  $('#userDetail').hidden = true;
  if (!showUsers && !$('#postTable').innerHTML) loadPosts().catch((err) => ($('#postTable').innerHTML = `<p class="error">${escapeHtml(err.message)}</p>`));
});

$('#userSearchBtn').addEventListener('click', () => loadUsers());
$('#userSort').addEventListener('change', () => loadUsers());
$('#userSearch').addEventListener('keydown', (e) => e.key === 'Enter' && loadUsers());
$('#postSearchBtn').addEventListener('click', () => loadPosts());
$('#postType').addEventListener('change', () => loadPosts());
$('#postSearch').addEventListener('keydown', (e) => e.key === 'Enter' && loadPosts());

/* --------------------------------------------------------- query lab -- */

let catalog = [];
let activeQuery = null;

function renderQueryDetail(query) {
  activeQuery = query;
  $$('#queryList button').forEach((b) => b.setAttribute('aria-current', String(b.dataset.id === query.id)));
  $('#queryDetail').innerHTML = `
    <h2>${escapeHtml(query.title)}</h2>
    <p class="sub">${escapeHtml(query.question)}</p>
    <div class="chips">${query.concepts.map((c) => `<span class="chip">${escapeHtml(c)}</span>`).join('')}</div>
    ${query.note ? `<p class="note" style="margin-top:0.8rem">${escapeHtml(query.note)}</p>` : ''}
    <pre class="sql">${escapeHtml(query.sql)}</pre>
    <div class="toolbar" style="margin:0">
      <button class="action" id="runQuery">Run query</button>
      <button class="action quiet" id="copySql">Copy SQL</button>
      <span class="readout" id="queryStatus"></span>
    </div>`;
  $('#queryResult').hidden = true;

  $('#runQuery').addEventListener('click', runActiveQuery);
  $('#copySql').addEventListener('click', async () => {
    await navigator.clipboard.writeText(query.sql).catch(() => {});
    $('#copySql').textContent = 'Copied';
    setTimeout(() => ($('#copySql').textContent = 'Copy SQL'), 1500);
  });
}

async function runActiveQuery() {
  const button = $('#runQuery');
  button.disabled = true;
  $('#queryStatus').textContent = 'running…';
  try {
    const result = await api(`/queries/${activeQuery.id}/run`, { method: 'POST' });
    $('#queryStatus').innerHTML = `<strong>${result.rowCount}</strong> rows in <strong>${result.elapsedMs} ms</strong>`;
    const panel = $('#queryResult');
    panel.hidden = false;
    panel.innerHTML = `<h3>Result</h3><p class="sub">${result.rowCount} rows returned, measured at ${result.elapsedMs} ms including the round trip.</p><div class="table-wrap">${table(result.rows)}</div>`;
  } catch (err) {
    $('#queryStatus').textContent = '';
    $('#queryResult').hidden = false;
    $('#queryResult').innerHTML = `<p class="error">${escapeHtml(err.message)}</p>`;
  } finally {
    button.disabled = false;
  }
}

views.queries = {
  loaded: false,
  async load() {
    try {
      catalog = await api('/queries');
      $('#queryList').innerHTML = catalog
        .map(
          (q) => `<button data-id="${q.id}"><span>${escapeHtml(q.title)}</span><small>${escapeHtml(q.concepts.slice(0, 2).join(', '))}</small></button>`
        )
        .join('');
      $('#queryList').addEventListener('click', (event) => {
        const button = event.target.closest('button[data-id]');
        if (button) renderQueryDetail(catalog.find((q) => q.id === button.dataset.id));
      });
      renderQueryDetail(catalog[0]);
      fillBenchmarkOptions();
      fillConsoleSamples();
    } catch (err) {
      $('#queryDetail').innerHTML = `<p class="error">${escapeHtml(err.message)}</p>`;
    }
  }
};

/* ----------------------------------------------------------- console -- */

function fillConsoleSamples() {
  const select = $('#sampleQuery');
  if (!select || select.options.length > 1) return;
  catalog.forEach((q) => {
    const option = document.createElement('option');
    option.value = q.id;
    option.textContent = q.title;
    select.appendChild(option);
  });
  select.addEventListener('change', () => {
    const query = catalog.find((q) => q.id === select.value);
    if (query) $('#customSql').value = query.sql.replace(/;\s*$/, '');
  });
}

$('#runCustom').addEventListener('click', async () => {
  const button = $('#runCustom');
  const out = $('#customOut');
  button.disabled = true;
  out.innerHTML = '<p class="loading">running…</p>';
  try {
    const result = await api('/sql', { method: 'POST', body: { sql: $('#customSql').value } });
    out.innerHTML = `<p class="readout" style="margin:0.8rem 0"><strong>${result.rowCount}</strong> rows in <strong>${result.elapsedMs} ms</strong>${result.truncated ? ' · showing the first 200' : ''}</p><div class="table-wrap">${table(result.rows)}</div>`;
  } catch (err) {
    out.innerHTML = `<p class="error">${escapeHtml(err.message)}</p>`;
  } finally {
    button.disabled = false;
  }
});

views.console = {
  loaded: false,
  async load() {
    if (!catalog.length) catalog = await api('/queries').catch(() => []);
    fillConsoleSamples();
    try {
      const schema = await api('/schema');
      const grouped = schema.columns.reduce((acc, row) => {
        (acc[row.table_name] = acc[row.table_name] || []).push(row.column_name);
        return acc;
      }, {});
      $('#consoleSchema').innerHTML = Object.entries(grouped)
        .map(([name, cols]) => `<div><strong>${escapeHtml(name)}</strong>(${cols.map(escapeHtml).join(', ')})</div>`)
        .join('') + '<div style="margin-top:0.5rem"><strong>v_post_engagement</strong>, <strong>v_user_engagement</strong>, <strong>v_daily_engagement</strong></div>';
    } catch (err) {
      $('#consoleSchema').innerHTML = `<p class="error">${escapeHtml(err.message)}</p>`;
    }
  }
};

/* --------------------------------------------------------- index lab -- */

const benchmarkHistory = {};

function fillBenchmarkOptions() {
  const select = $('#benchQuery');
  if (!select || select.options.length) return;
  catalog
    .filter((q) => q.benchmark)
    .concat(catalog.filter((q) => !q.benchmark))
    .forEach((q) => {
      const option = document.createElement('option');
      option.value = q.id;
      option.textContent = q.benchmark ? `${q.title}  (good demo)` : q.title;
      select.appendChild(option);
    });
}

async function refreshIndexState() {
  const state = await api('/indexes');
  $('#indexDot').className = `dot ${state.enabled ? '' : 'off'}`;
  $('#indexState').textContent = state.enabled
    ? `${state.secondaryCount} project indexes in place, ${state.totalIndexes} indexes on the database in total`
    : `No project indexes. ${state.totalIndexes} remain, created by the keys and foreign keys themselves.`;
  $('#indexTable').innerHTML = table(
    state.indexes.map((row) => ({
      index: row.indexname,
      table: row.tablename,
      columns: row.definition,
      created_by: row.created_by
    })),
    { truncate: ['columns'] }
  );
}

$('#dropIndexes').addEventListener('click', () => toggleIndexes('disable'));
$('#createIndexes').addEventListener('click', () => toggleIndexes('enable'));

async function toggleIndexes(action) {
  const buttons = [$('#dropIndexes'), $('#createIndexes')];
  buttons.forEach((b) => (b.disabled = true));
  $('#indexState').textContent = action === 'enable' ? 'building indexes…' : 'dropping indexes…';
  try {
    await api(`/indexes/${action}`, { method: 'POST' });
    await refreshIndexState();
  } catch (err) {
    $('#indexState').textContent = err.message;
  } finally {
    buttons.forEach((b) => (b.disabled = false));
  }
}

$('#runBenchmark').addEventListener('click', async () => {
  const button = $('#runBenchmark');
  const out = $('#benchOut');
  button.disabled = true;
  // Keep any earlier result on screen: the point of this panel is the comparison.
  const banner = document.createElement('p');
  banner.className = 'loading';
  banner.textContent = 'running EXPLAIN ANALYZE…';
  if (benchmarkHistory[$('#benchQuery').value]) out.prepend(banner);
  else out.innerHTML = '<p class="loading">running EXPLAIN ANALYZE…</p>';
  try {
    const result = await api('/benchmark', {
      method: 'POST',
      body: { queryId: $('#benchQuery').value, runs: Number($('#benchRuns').value) }
    });
    const bucket = (benchmarkHistory[result.queryId] = benchmarkHistory[result.queryId] || {});
    bucket[result.indexesEnabled ? 'indexed' : 'unindexed'] = result;
    bucket.last = result;
    renderBenchmark(result.queryId);
  } catch (err) {
    out.innerHTML = `<p class="error">${escapeHtml(err.message)}</p>`;
  } finally {
    button.disabled = false;
  }
});

function renderBenchmark(queryId) {
  const bucket = benchmarkHistory[queryId];
  const latest = bucket.last || bucket.indexed || bucket.unindexed;
  const condition = latest.indexesEnabled ? 'with indexes' : 'without indexes';
  const bars = [];
  if (bucket.unindexed) bars.push({ label: 'without indexes', value: bucket.unindexed.average, flag: true });
  if (bucket.indexed) bars.push({ label: 'with indexes', value: bucket.indexed.average });

  let verdict = '<p class="note">Now flip the indexes with the buttons above and run the same benchmark again to see both bars.</p>';
  if (bucket.indexed && bucket.unindexed) {
    const speedup = bucket.unindexed.average / bucket.indexed.average;
    const saved = bucket.unindexed.average - bucket.indexed.average;
    verdict =
      speedup >= 1.05
        ? `<p class="note">Indexes made this query <strong>${speedup.toFixed(1)}×</strong> faster, saving ${saved.toFixed(1)} ms per execution.</p>`
        : `<p class="note">Almost no difference here (${speedup.toFixed(2)}×). That is a real result worth explaining: this query reads most of the table anyway, so a sequential scan is already the planner's best option.</p>`;
  }

  $('#benchOut').innerHTML = `
    <h3 style="margin-bottom:0.2rem">${escapeHtml(latest.title)}</h3>
    <p class="sub">Average execution time over ${latest.runs} run(s), measured around the query.</p>
    ${barChart(bars)}
    ${verdict}
    <p class="readout" style="margin-top:0.8rem">last run (${condition}): best ${latest.best} ms · worst ${latest.worst} ms</p>
    <div class="chips" style="margin-top:0.5rem">${latest.access
      .map(
        (step) =>
          `<span class="chip ${step.usesIndex ? 'on' : 'off'}">${escapeHtml(step.table || 'derived')} · ${escapeHtml(step.type)}${
            step.key ? ` · ${escapeHtml(step.key)}` : ''
          } · ${fmt(step.rows)} rows</span>`
      )
      .join('')}</div>
    <p class="sub" style="margin-top:0.5rem">What EXPLAIN reported on the last run, ${escapeHtml(condition)}. Green means MySQL used an index; red (type ALL) means it read the whole table.</p>`;
}

views.indexes = {
  loaded: false,
  async load() {
    if (!catalog.length) catalog = await api('/queries').catch(() => []);
    fillBenchmarkOptions();
    refreshIndexState().catch((err) => ($('#indexState').textContent = err.message));
  }
};


/* ------------------------------------------------- stored programs ---- */

let newPostId = null;

async function refreshAudit() {
  const audit = await api('/audit');
  const rows = [
    ...audit.interactions.map((r) => ({
      when: r.recorded_at, event: `${r.interaction_type} on post ${r.post_id}`,
      by: r.username || r.user_id, written_by: 'trg_interaction_audit'
    })),
    ...audit.posts.map((r) => ({
      when: r.recorded_at, event: `post ${r.post_id} deleted (${r.topic})`,
      by: r.user_id, written_by: 'trg_post_delete_audit'
    }))
  ]
    .sort((a, b) => String(b.when).localeCompare(String(a.when)))
    .slice(0, 12);
  $('#auditOut').innerHTML = rows.length ? table(rows) : '<p class="empty">Nothing audited yet. Create a post below and react to it.</p>';
}

views.programs = {
  loaded: false,
  async load() {
    try {
      const { routines, triggers } = await api('/programs');
      $('#programList').innerHTML = table([
        ...routines.map((r) => ({ kind: r.kind.toLowerCase(), name: r.name, fires: '—' })),
        ...triggers.map((t) => ({
          kind: 'trigger', name: t.name, fires: `${t.timing.toLowerCase()} ${t.event.toLowerCase()} on ${t.on_table}`
        }))
      ]);
      await refreshAudit();
    } catch (err) {
      $('#programList').innerHTML = `<p class="error">${escapeHtml(err.message)}</p>`;
    }

    const show = (target, html) => ($(target).innerHTML = html);

    $('#runFnPost').addEventListener('click', async () => {
      try {
        const r = await api(`/functions/post/${Number($('#fnPostId').value)}`);
        show('#fnOut', `<p class="readout"><strong>${r.points_from_function}</strong> points for post ${r.post_id} (${escapeHtml(r.topic)}) by ${escapeHtml(r.author)}. The view agrees: ${r.points_from_view}.</p>`);
      } catch (err) { show('#fnOut', `<p class="error">${escapeHtml(err.message)}</p>`); }
    });

    $('#runFnUser').addEventListener('click', async () => {
      try {
        const r = await api(`/functions/user/${Number($('#fnUserId').value)}`);
        show('#fnOut', `<p class="readout"><strong>${r.points_from_function}</strong> points earned by ${escapeHtml(r.username)} across ${r.posts} posts.</p>`);
      } catch (err) { show('#fnOut', `<p class="error">${escapeHtml(err.message)}</p>`); }
    });

    $('#runProcUser').addEventListener('click', async () => {
      show('#procOut', '<p class="loading">running the cursor…</p>');
      try {
        const r = await api('/procedures/user-report', { method: 'POST', body: { userId: Number($('#procUserId').value) } });
        show('#procOut', `<p class="readout">cursor finished in <strong>${r.elapsedMs} ms</strong></p><div class="table-wrap">${table(r.rows)}</div>`);
      } catch (err) { show('#procOut', `<p class="error">${escapeHtml(err.message)}</p>`); }
    });

    $('#runProcTrending').addEventListener('click', async () => {
      show('#procOut', '<p class="loading">running the cursor over every post in the window…</p>');
      try {
        const r = await api('/procedures/trending-report', { method: 'POST', body: { days: Number($('#procDays').value), limit: 10 } });
        show('#procOut', `<p class="readout">cursor finished in <strong>${r.elapsedMs} ms</strong> over the last ${r.days} days</p><div class="table-wrap">${table(r.rows)}</div>`);
      } catch (err) { show('#procOut', `<p class="error">${escapeHtml(err.message)}</p>`); }
    });

    $('#createPost').addEventListener('click', async () => {
      try {
        const r = await api('/posts', {
          method: 'POST',
          body: {
            userId: 1,
            topic: $('#newTopic').value || 'viva demo',
            content: $('#newContent').value || 'Created live from the dashboard.',
            postType: 'text'
          }
        });
        newPostId = r.post_id;
        $('#postActions').hidden = false;
        $('#newPostLabel').textContent = `post ${r.post_id} created`;
        show('#crudOut', `<p class="note">Row inserted into posts. Now react to it, or delete it and watch the audit table.</p>`);
        await refreshAudit();
      } catch (err) { show('#crudOut', `<p class="error">${escapeHtml(err.message)}</p>`); }
    });

    const react = async (userId, label) => {
      if (!newPostId) return;
      try {
        const r = await api('/interactions', { method: 'POST', body: { postId: newPostId, userId, type: 'like' } });
        show('#crudOut', `<p class="note">${label} — the post is now worth <strong>${r.points}</strong> point(s), and trg_interaction_audit logged it.</p>`);
      } catch (err) {
        show('#crudOut', `<p class="error">MySQL refused it: ${escapeHtml(err.message)}</p>`);
      }
      await refreshAudit();
    };

    $('#likeAsOther').addEventListener('click', () => react(2, 'Liked by another user'));
    $('#likeAsAuthor').addEventListener('click', () => react(1, 'Liked by the author'));

    $('#deletePost').addEventListener('click', async () => {
      if (!newPostId) return;
      try {
        const r = await api(`/posts/${newPostId}`, { method: 'DELETE' });
        show('#crudOut', `<p class="note">Post ${r.deleted} deleted. Its comments and interactions went with it through ON DELETE CASCADE, and trg_post_delete_audit kept a record.</p>`);
        newPostId = null;
        $('#postActions').hidden = true;
        await refreshAudit();
      } catch (err) { show('#crudOut', `<p class="error">${escapeHtml(err.message)}</p>`); }
    });
  }
};

/* ------------------------------------------------------------ schema -- */

views.schema = {
  loaded: false,
  async load() {
    try {
      const { columns, constraints, counts } = await api('/schema');
      const rowCounts = Object.fromEntries(counts.map((c) => [c.table_name, c.approx_rows]));
      const grouped = columns.reduce((acc, row) => {
        (acc[row.table_name] = acc[row.table_name] || []).push(row);
        return acc;
      }, {});

      $('#schemaTables').innerHTML = Object.entries(grouped)
        .map(([name, cols]) => {
          const tableConstraints = constraints.filter((c) => c.table_name === name);
          const keyOf = (column) => {
            const matches = tableConstraints.filter((c) => c.column_name === column);
            if (matches.some((c) => c.constraint_type === 'PRIMARY KEY')) return 'PK';
            if (matches.some((c) => c.constraint_type === 'FOREIGN KEY')) return 'FK';
            if (matches.some((c) => c.constraint_type === 'UNIQUE')) return 'UQ';
            return '';
          };
          const rows = cols.map((c) => ({
            column: c.column_name,
            type: c.data_type.replace('timestamp with time zone', 'timestamptz').replace('character varying', 'varchar'),
            key: keyOf(c.column_name),
            nullable: c.is_nullable === 'YES' ? 'yes' : 'no'
          }));
          return `<h3 style="margin-top:1rem">${escapeHtml(name)} <span class="readout">· ${fmt(rowCounts[name] ?? 0)} rows</span></h3>
                  <div class="table-wrap">${table(rows)}</div>`;
        })
        .join('');
    } catch (err) {
      $('#schemaTables').innerHTML = `<p class="error">${escapeHtml(err.message)}</p>`;
    }
  }
};

/* -------------------------------------------------------------- boot -- */

/**
 * On a brand new deployment the server is up before the database has any
 * tables in it, so the page waits here and reports progress instead of
 * showing a wall of failed requests.
 */
async function waitForSetup() {
  const statusLine = $('#bootStatus');
  for (let attempt = 0; attempt < 600; attempt++) {
    try {
      const state = await api('/status');
      if (state.ready) return true;
      statusLine.className = state.phase === 'failed' ? 'status failed' : 'status';
      statusLine.textContent = state.message;
      if (state.phase === 'failed') return false;
    } catch (err) {
      statusLine.textContent = 'waiting for the server';
    }
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
  statusLine.textContent = 'Setup is taking longer than expected. Check the server logs.';
  return false;
}

(async () => {
  const ready = await waitForSetup();
  if (!ready) return;
  $('#boot').hidden = true;
  $('#shell').hidden = false;
  const initial = (location.hash || '#overview').slice(1);
  showView(views[initial] ? initial : 'overview');
  // The sidebar summary comes from the overview payload, so load it even when
  // the visitor lands directly on another section.
  if (!views.overview.loaded) {
    views.overview.loaded = true;
    views.overview.load();
  }
})();
