'use strict';

const fs = require('fs');
const path = require('path');
const express = require('express');
const { pool, timedQuery } = require('../db/pool');
const { getStatus } = require('../db/bootstrap');
const { getQuery, listQueries } = require('../queries/catalog');

const router = express.Router();
const sqlFile = (name) => fs.readFileSync(path.join(__dirname, '..', 'db', name), 'utf8');
const ALLOW_CUSTOM_SQL = process.env.ALLOW_CUSTOM_SQL !== 'false';
const STATEMENT_TIMEOUT = process.env.STATEMENT_TIMEOUT || '8s';

/** Wraps an async handler so a rejected promise becomes a 500 with a message. */
const wrap = (fn) => (req, res) => {
  Promise.resolve(fn(req, res)).catch((err) => {
    console.error(`${req.method} ${req.originalUrl} failed:`, err.message);
    res.status(500).json({ error: err.message });
  });
};

// ---------------------------------------------------------------- setup ---
// Reports first-run progress so the page can show a setup screen.
router.get('/status', (_req, res) => res.json(getStatus()));

// Everything below needs a database that actually has tables in it.
router.use((req, res, next) => {
  const state = getStatus();
  if (state.ready || req.path === '/health') return next();
  res.status(503).json({
    error: state.error || 'The database is still being set up',
    setup: state
  });
});

// ---------------------------------------------------------------- health ---
router.get(
  '/health',
  wrap(async (_req, res) => {
    const { rows } = await pool.query('SELECT NOW() AS server_time, version() AS version');
    res.json({ status: 'ok', ...rows[0] });
  })
);

// ------------------------------------------------------------- dashboard ---
router.get(
  '/overview',
  wrap(async (_req, res) => {
    const [totals, daily, mix, topPosts, topUsers, types] = await Promise.all([
      pool.query(`
        SELECT (SELECT count(*) FROM users)        AS users,
               (SELECT count(*) FROM posts)        AS posts,
               (SELECT count(*) FROM comments)     AS comments,
               (SELECT count(*) FROM followers)    AS follows,
               (SELECT count(*) FROM interactions) AS interactions,
               (SELECT min(created_at)::date FROM interactions) AS first_activity,
               (SELECT max(created_at)::date FROM interactions) AS last_activity,
               pg_size_pretty(pg_database_size(current_database())) AS database_size
      `),
      pool.query(`
        SELECT activity_date, interactions, active_users, likes, shares
        FROM v_daily_engagement
        WHERE activity_date >= (CURRENT_DATE - INTERVAL '45 days')
        ORDER BY activity_date
      `),
      pool.query(`
        SELECT interaction_type, count(*) AS n
        FROM interactions GROUP BY interaction_type ORDER BY n DESC
      `),
      pool.query(`
        SELECT pe.post_id, pe.author, pe.post_type, left(p.content, 70) AS preview,
               pe.likes, pe.comments, pe.shares, pe.engagement_score
        FROM v_post_engagement pe
        JOIN posts p ON p.post_id = pe.post_id
        ORDER BY pe.engagement_score DESC LIMIT 8
      `),
      pool.query(`
        SELECT username, country, posts, engagement_score, followers
        FROM v_user_engagement
        ORDER BY engagement_score DESC LIMIT 8
      `),
      pool.query(`
        SELECT post_type, count(*) AS posts, round(avg(engagement_score), 1) AS avg_score
        FROM v_post_engagement GROUP BY post_type ORDER BY avg_score DESC
      `)
    ]);

    res.json({
      totals: totals.rows[0],
      daily: daily.rows,
      mix: mix.rows,
      topPosts: topPosts.rows,
      topUsers: topUsers.rows,
      byType: types.rows
    });
  })
);

// ----------------------------------------------------------------- users ---
router.get(
  '/users',
  wrap(async (req, res) => {
    const search = (req.query.search || '').trim();
    const sort = ['engagement_score', 'followers', 'posts', 'username'].includes(req.query.sort)
      ? req.query.sort
      : 'engagement_score';
    const direction = sort === 'username' ? 'ASC' : 'DESC';
    const limit = Math.min(Number(req.query.limit) || 25, 100);

    const { rows } = await pool.query(
      `SELECT user_id, username, full_name, country, posts, followers, following,
              engagement_score, avg_score_per_post, joined_at::date AS joined_on
       FROM v_user_engagement
       WHERE ($1 = '' OR username ILIKE '%' || $1 || '%' OR full_name ILIKE '%' || $1 || '%')
       ORDER BY ${sort} ${direction}
       LIMIT $2`,
      [search, limit]
    );
    res.json(rows);
  })
);

router.get(
  '/users/:id',
  wrap(async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'user id must be a number' });

    const [profile, posts, recent] = await Promise.all([
      pool.query('SELECT * FROM v_user_engagement WHERE user_id = $1', [id]),
      pool.query(
        `SELECT post_id, post_type, posted_at::date AS posted_on, likes, comments,
                shares, views, engagement_score
         FROM v_post_engagement WHERE author_id = $1
         ORDER BY engagement_score DESC LIMIT 10`,
        [id]
      ),
      pool.query(
        `SELECT i.interaction_type, i.created_at, i.post_id, u.username AS post_author
         FROM interactions i
         JOIN posts p ON p.post_id = i.post_id
         JOIN users u ON u.user_id = p.user_id
         WHERE i.user_id = $1
         ORDER BY i.created_at DESC LIMIT 10`,
        [id]
      )
    ]);

    if (!profile.rows.length) return res.status(404).json({ error: 'No user with that id' });
    res.json({ profile: profile.rows[0], topPosts: posts.rows, recentActivity: recent.rows });
  })
);

// ----------------------------------------------------------------- posts ---
router.get(
  '/posts',
  wrap(async (req, res) => {
    const search = (req.query.search || '').trim();
    const type = ['text', 'image', 'video', 'link'].includes(req.query.type) ? req.query.type : '';
    const limit = Math.min(Number(req.query.limit) || 25, 100);

    const { rows } = await pool.query(
      `SELECT pe.post_id, pe.author, pe.post_type, left(p.content, 90) AS preview,
              pe.posted_at::date AS posted_on, pe.likes, pe.comments, pe.shares,
              pe.views, pe.engagement_score
       FROM v_post_engagement pe
       JOIN posts p ON p.post_id = pe.post_id
       WHERE ($1 = '' OR p.content ILIKE '%' || $1 || '%')
         AND ($2 = '' OR pe.post_type = $2)
       ORDER BY pe.engagement_score DESC
       LIMIT $3`,
      [search, type, limit]
    );
    res.json(rows);
  })
);

// ------------------------------------------------------------- query lab ---
router.get('/queries', (_req, res) => res.json(listQueries()));

router.post(
  '/queries/:id/run',
  wrap(async (req, res) => {
    const query = getQuery(req.params.id);
    if (!query) return res.status(404).json({ error: 'No query with that id' });

    const { rows, fields, elapsedMs } = await timedQuery(query.sql);
    res.json({
      id: query.id,
      title: query.title,
      sql: query.sql,
      fields,
      rows,
      rowCount: rows.length,
      elapsedMs: Number(elapsedMs.toFixed(2))
    });
  })
);

// A deliberately narrow door for user written SQL: read only transaction,
// single statement, SELECT or WITH only, and a hard statement timeout.
const BLOCKED = /\b(insert|update|delete|drop|alter|create|truncate|grant|revoke|copy|vacuum|reindex|call|do|set|begin|commit|rollback)\b/i;

router.post(
  '/sql',
  wrap(async (req, res) => {
    if (!ALLOW_CUSTOM_SQL) return res.status(403).json({ error: 'The SQL console is switched off on this deployment' });

    const raw = String(req.body.sql || '').trim().replace(/;+\s*$/, '');
    if (!raw) return res.status(400).json({ error: 'Type a query first' });
    if (raw.includes(';')) return res.status(400).json({ error: 'Run one statement at a time' });
    if (!/^(select|with)\b/i.test(raw)) return res.status(400).json({ error: 'Only SELECT and WITH queries can run here' });
    if (BLOCKED.test(raw)) return res.status(400).json({ error: 'This console is read only, so that keyword is not allowed' });

    const client = await pool.connect();
    try {
      await client.query('BEGIN READ ONLY');
      await client.query(`SET LOCAL statement_timeout = '${STATEMENT_TIMEOUT}'`);
      const started = process.hrtime.bigint();
      const result = await client.query(`SELECT * FROM (${raw}) AS user_query LIMIT 200`);
      const elapsedMs = Number(process.hrtime.bigint() - started) / 1e6;
      await client.query('ROLLBACK');
      res.json({
        fields: result.fields.map((f) => f.name),
        rows: result.rows,
        rowCount: result.rows.length,
        elapsedMs: Number(elapsedMs.toFixed(2)),
        truncated: result.rows.length === 200
      });
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      res.status(400).json({ error: err.message });
    } finally {
      client.release();
    }
  })
);

// ------------------------------------------------------------- index lab ---
router.get(
  '/indexes',
  wrap(async (_req, res) => {
    const { rows } = await pool.query(`
      SELECT i.indexname,
             i.tablename,
             i.indexdef,
             pg_size_pretty(pg_relation_size(c.oid)) AS size
      FROM pg_indexes i
      JOIN pg_class c ON c.relname = i.indexname
      WHERE i.schemaname = 'public'
      ORDER BY (i.indexname LIKE 'idx%') DESC, i.tablename, i.indexname
    `);
    const secondary = rows.filter((r) => r.indexname.startsWith('idx_'));
    res.json({
      enabled: secondary.length > 0,
      secondaryCount: secondary.length,
      indexes: rows
    });
  })
);

router.post(
  '/indexes/:action',
  wrap(async (req, res) => {
    const { action } = req.params;
    if (!['enable', 'disable'].includes(action)) {
      return res.status(400).json({ error: 'action must be enable or disable' });
    }
    const started = Date.now();
    await pool.query(sqlFile(action === 'enable' ? 'indexes.sql' : 'drop_indexes.sql'));
    const { rows } = await pool.query(
      "SELECT count(*)::int AS n FROM pg_indexes WHERE schemaname = 'public' AND indexname LIKE 'idx_%'"
    );
    res.json({ enabled: action === 'enable', secondaryCount: rows[0].n, tookMs: Date.now() - started });
  })
);

// ------------------------------------------------------------- benchmark ---
/** Runs EXPLAIN (ANALYZE) a few times and reports the timings PostgreSQL itself measured. */
async function explainAnalyze(sql) {
  const { rows } = await pool.query(`EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) ${sql.replace(/;\s*$/, '')}`);
  const plan = rows[0]['QUERY PLAN'][0];
  return {
    executionMs: plan['Execution Time'],
    planningMs: plan['Planning Time'],
    node: plan.Plan['Node Type'],
    scans: collectScans(plan.Plan)
  };
}

function collectScans(node, found = []) {
  if (node['Node Type'] && /Scan/.test(node['Node Type'])) {
    found.push({
      type: node['Node Type'],
      relation: node['Relation Name'] || node['Index Name'] || null,
      rows: node['Actual Rows']
    });
  }
  (node.Plans || []).forEach((child) => collectScans(child, found));
  return found;
}

router.post(
  '/benchmark',
  wrap(async (req, res) => {
    const query = getQuery(req.body.queryId);
    if (!query) return res.status(404).json({ error: 'No query with that id' });
    const runs = Math.min(Math.max(Number(req.body.runs) || 3, 1), 5);

    const attempts = [];
    for (let i = 0; i < runs; i++) attempts.push(await explainAnalyze(query.sql));

    const times = attempts.map((a) => a.executionMs);
    const { rows } = await pool.query(
      "SELECT count(*)::int AS n FROM pg_indexes WHERE schemaname = 'public' AND indexname LIKE 'idx_%'"
    );

    res.json({
      queryId: query.id,
      title: query.title,
      runs,
      indexesEnabled: rows[0].n > 0,
      secondaryCount: rows[0].n,
      best: Number(Math.min(...times).toFixed(2)),
      worst: Number(Math.max(...times).toFixed(2)),
      average: Number((times.reduce((a, b) => a + b, 0) / times.length).toFixed(2)),
      planningMs: Number(attempts[0].planningMs.toFixed(2)),
      scans: attempts[0].scans
    });
  })
);

// ---------------------------------------------------------------- schema ---
router.get(
  '/schema',
  wrap(async (_req, res) => {
    const [columns, constraints, counts] = await Promise.all([
      pool.query(`
        SELECT table_name, column_name, data_type, is_nullable, ordinal_position
        FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name IN ('users','posts','comments','followers','interactions')
        ORDER BY table_name, ordinal_position
      `),
      pool.query(`
        SELECT tc.table_name, tc.constraint_type, tc.constraint_name,
               kcu.column_name, ccu.table_name AS references_table
        FROM information_schema.table_constraints tc
        LEFT JOIN information_schema.key_column_usage kcu
               ON kcu.constraint_name = tc.constraint_name
        LEFT JOIN information_schema.constraint_column_usage ccu
               ON ccu.constraint_name = tc.constraint_name AND tc.constraint_type = 'FOREIGN KEY'
        WHERE tc.table_schema = 'public'
          AND tc.table_name IN ('users','posts','comments','followers','interactions')
        ORDER BY tc.table_name, tc.constraint_type
      `),
      pool.query(`
        SELECT relname AS table_name, n_live_tup AS approx_rows
        FROM pg_stat_user_tables ORDER BY n_live_tup DESC
      `)
    ]);
    res.json({ columns: columns.rows, constraints: constraints.rows, counts: counts.rows });
  })
);

module.exports = router;
