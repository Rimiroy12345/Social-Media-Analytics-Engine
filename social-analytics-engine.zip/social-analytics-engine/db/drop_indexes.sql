-- Drops only the secondary indexes created by indexes.sql.
-- Primary key / UNIQUE constraint indexes are left alone, because
-- dropping those would break the constraints themselves.

DROP INDEX IF EXISTS idx_posts_user_id;
DROP INDEX IF EXISTS idx_posts_created_at;
DROP INDEX IF EXISTS idx_comments_post_id;
DROP INDEX IF EXISTS idx_comments_user_id;
DROP INDEX IF EXISTS idx_followers_followee;
DROP INDEX IF EXISTS idx_interactions_post_id;
DROP INDEX IF EXISTS idx_interactions_user_id;
DROP INDEX IF EXISTS idx_interactions_created_at;
DROP INDEX IF EXISTS idx_interactions_post_type;
DROP INDEX IF EXISTS idx_interactions_shares_only;

ANALYZE;
