'use strict';

/**
 * First-run setup.
 *
 * A fresh deployment points at an empty database. Rather than making someone
 * open a shell and run migrations by hand, the server checks on startup and
 * builds whatever is missing: tables, views, indexes, then the dataset.
 *
 * It is safe to run every boot. Existing data is left alone.
 * Set AUTO_SETUP=false to turn it off and manage the schema yourself.
 */

const fs = require('fs');
const path = require('path');
const { pool } = require('./pool');
const { seedDatabase } = require('./seed');

const read = (file) => fs.readFileSync(path.join(__dirname, file), 'utf8');

const status = {
  ready: false,
  phase: 'starting',
  message: 'connecting to the database',
  error: null,
  startedAt: Date.now(),
  finishedAt: null
};

const set = (phase, message) => {
  status.phase = phase;
  status.message = message;
  console.log(`[setup] ${message}`);
};

const getStatus = () => ({
  ...status,
  elapsedSeconds: Number(((( status.finishedAt || Date.now()) - status.startedAt) / 1000).toFixed(1))
});

async function waitForDatabase(attempts = 10) {
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      await pool.query('SELECT 1');
      return;
    } catch (err) {
      if (attempt === attempts) throw err;
      set('waiting', `database not reachable yet, retrying (${attempt}/${attempts})`);
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }
}

async function ensureDatabase() {
  try {
    await waitForDatabase();

    const client = await pool.connect();
    try {
      const { rows } = await client.query("SELECT to_regclass('users') AS users_table");
      const hasTables = rows[0].users_table !== null;

      if (!hasTables) {
        if (process.env.AUTO_SETUP === 'false') {
          throw new Error('No tables found and AUTO_SETUP is off. Run: npm run db:reset');
        }
        set('schema', 'creating tables');
        await client.query(read('schema.sql'));
      }

      // Views and indexes are cheap and idempotent, so refresh them either way.
      set('views', 'creating views');
      await client.query(read('views.sql'));
      set('indexes', 'creating indexes');
      await client.query(read('indexes.sql'));

      const { rows: counts } = await client.query('SELECT count(*)::int AS n FROM users');
      if (counts[0].n === 0) {
        if (process.env.AUTO_SETUP === 'false') {
          set('empty', 'tables are empty and AUTO_SETUP is off');
        } else {
          set('seeding', 'generating the dataset, this takes a few seconds');
          await seedDatabase(client, (message) => set('seeding', message));
        }
      } else {
        set('ready', `found an existing dataset with ${counts[0].n.toLocaleString()} users`);
      }
    } finally {
      client.release();
    }

    status.ready = true;
    status.finishedAt = Date.now();
    set('ready', `database ready in ${getStatus().elapsedSeconds} s`);
  } catch (err) {
    status.error = err.message;
    status.finishedAt = Date.now();
    set('failed', `setup failed: ${err.message}`);
  }
}

module.exports = { ensureDatabase, getStatus };
