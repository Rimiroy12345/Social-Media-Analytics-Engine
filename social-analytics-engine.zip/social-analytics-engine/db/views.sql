-- ============================================================
--  Analytical views
--  Engagement weights used everywhere in this project:
--    view = 0.2   like = 1   save = 2   share = 3   comment = 2
-- ============================================================

DROP VIEW IF EXISTS v_daily_engagement CASCADE;
DROP VIEW IF EXISTS v_user_engagement  CASCADE;
DROP VIEW IF EXISTS v_post_engagement  CASCADE;

-- One row per post, with every engagement metric derived on the fly.
CREATE VIEW v_post_engagement AS
WITH interaction_rollup AS (
    SELECT
        post_id,
        COUNT(*)                                                  AS total_interactions,
        COUNT(*) FILTER (WHERE interaction_type = 'like')         AS likes,
        COUNT(*) FILTER (WHERE interaction_type = 'share')        AS shares,
        COUNT(*) FILTER (WHERE interaction_type = 'save')         AS saves,
        COUNT(*) FILTER (WHERE interaction_type = 'view')         AS views,
        COUNT(DISTINCT user_id)                                   AS unique_engagers,
        MAX(created_at)                                           AS last_interaction_at
    FROM interactions
    GROUP BY post_id
),
comment_rollup AS (
    SELECT post_id, COUNT(*) AS comments
    FROM comments
    GROUP BY post_id
)
SELECT
    p.post_id,
    p.user_id                                   AS author_id,
    u.username                                  AS author,
    p.post_type,
    p.created_at                                AS posted_at,
    COALESCE(ir.likes, 0)                       AS likes,
    COALESCE(ir.shares, 0)                      AS shares,
    COALESCE(ir.saves, 0)                       AS saves,
    COALESCE(ir.views, 0)                       AS views,
    COALESCE(cr.comments, 0)                    AS comments,
    COALESCE(ir.total_interactions, 0)          AS total_interactions,
    COALESCE(ir.unique_engagers, 0)             AS unique_engagers,
    ir.last_interaction_at,
    ROUND(
        COALESCE(ir.views,  0) * 0.2 +
        COALESCE(ir.likes,  0) * 1.0 +
        COALESCE(ir.saves,  0) * 2.0 +
        COALESCE(ir.shares, 0) * 3.0 +
        COALESCE(cr.comments, 0) * 2.0
    , 1)                                        AS engagement_score
FROM posts p
JOIN users u                 ON u.user_id = p.user_id
LEFT JOIN interaction_rollup ir ON ir.post_id = p.post_id
LEFT JOIN comment_rollup     cr ON cr.post_id = p.post_id;

-- One row per user: what they publish and how well it lands.
CREATE VIEW v_user_engagement AS
SELECT
    u.user_id,
    u.username,
    u.full_name,
    u.country,
    u.created_at                                            AS joined_at,
    COUNT(pe.post_id)                                       AS posts,
    COALESCE(SUM(pe.engagement_score), 0)                   AS engagement_score,
    ROUND(COALESCE(AVG(pe.engagement_score), 0), 1)         AS avg_score_per_post,
    COALESCE(SUM(pe.likes), 0)                              AS likes_received,
    COALESCE(SUM(pe.comments), 0)                           AS comments_received,
    (SELECT COUNT(*) FROM followers f WHERE f.followee_id = u.user_id) AS followers,
    (SELECT COUNT(*) FROM followers f WHERE f.follower_id = u.user_id) AS following
FROM users u
LEFT JOIN v_post_engagement pe ON pe.author_id = u.user_id
GROUP BY u.user_id, u.username, u.full_name, u.country, u.created_at;

-- One row per calendar day of platform activity.
CREATE VIEW v_daily_engagement AS
SELECT
    created_at::date                                          AS activity_date,
    COUNT(*)                                                  AS interactions,
    COUNT(*) FILTER (WHERE interaction_type = 'like')         AS likes,
    COUNT(*) FILTER (WHERE interaction_type = 'share')        AS shares,
    COUNT(*) FILTER (WHERE interaction_type = 'save')         AS saves,
    COUNT(*) FILTER (WHERE interaction_type = 'view')         AS views,
    COUNT(DISTINCT user_id)                                   AS active_users,
    COUNT(DISTINCT post_id)                                   AS posts_touched
FROM interactions
GROUP BY created_at::date;
