'use strict';

require('dotenv').config();
const { Pool } = require('pg');

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  console.error(
    '\nDATABASE_URL is not set.\n' +
      'Copy .env.example to .env and paste your PostgreSQL connection string into it.\n' +
      'On Render, add DATABASE_URL in the web service Environment tab.\n'
  );
  process.exit(1);
}

// Local Postgres does not speak TLS; hosted providers require it.
const isLocal = /@(localhost|127\.0\.0\.1)/.test(connectionString);
const ssl = isLocal || process.env.PGSSL === 'off' ? false : { rejectUnauthorized: false };

const pool = new Pool({
  connectionString,
  ssl,
  max: Number(process.env.PG_POOL_MAX || 5),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 15000
});

pool.on('error', (err) => {
  console.error('Idle client error:', err.message);
});

/** Run a query and also report how long it took, in milliseconds. */
async function timedQuery(text, params = []) {
  const started = process.hrtime.bigint();
  const result = await pool.query(text, params);
  const elapsedMs = Number(process.hrtime.bigint() - started) / 1e6;
  return { rows: result.rows, fields: result.fields.map((f) => f.name), elapsedMs };
}

module.exports = { pool, timedQuery, ssl };
