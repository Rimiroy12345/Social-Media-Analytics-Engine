-- ============================================================
--  Social Media Analytics Engine - relational schema
--  Target DBMS: PostgreSQL 14+
--  Design notes: the schema is in 3NF. Every non-key attribute
--  depends on the whole primary key and nothing but the key.
--  Engagement counts are never stored on posts/users - they are
--  always derived, so the data can never disagree with itself.
-- ============================================================

CREATE TABLE users (
    user_id     SERIAL PRIMARY KEY,
    username    VARCHAR(30)  NOT NULL UNIQUE,
    full_name   VARCHAR(80)  NOT NULL,
    email       VARCHAR(120) NOT NULL UNIQUE,
    bio         TEXT,
    country     VARCHAR(40)  NOT NULL,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT users_email_shape CHECK (email LIKE '%@%.%')
);

CREATE TABLE posts (
    post_id     SERIAL PRIMARY KEY,
    user_id     INTEGER     NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    content     TEXT        NOT NULL,
    post_type   VARCHAR(10) NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT posts_type_allowed CHECK (post_type IN ('text', 'image', 'video', 'link')),
    CONSTRAINT posts_content_not_blank CHECK (length(btrim(content)) > 0)
);

CREATE TABLE comments (
    comment_id  SERIAL PRIMARY KEY,
    post_id     INTEGER     NOT NULL REFERENCES posts(post_id) ON DELETE CASCADE,
    user_id     INTEGER     NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    content     TEXT        NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Many-to-many relationship of users with themselves.
-- The composite primary key is what stops a duplicate follow.
CREATE TABLE followers (
    follower_id INTEGER     NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    followee_id INTEGER     NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    followed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (follower_id, followee_id),
    CONSTRAINT followers_no_self_follow CHECK (follower_id <> followee_id)
);

-- The high-volume fact table. One row per engagement event.
CREATE TABLE interactions (
    interaction_id   BIGSERIAL PRIMARY KEY,
    post_id          INTEGER     NOT NULL REFERENCES posts(post_id) ON DELETE CASCADE,
    user_id          INTEGER     NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    interaction_type VARCHAR(10) NOT NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT interactions_type_allowed
        CHECK (interaction_type IN ('like', 'share', 'save', 'view')),
    CONSTRAINT interactions_one_per_user_per_type
        UNIQUE (post_id, user_id, interaction_type)
);

COMMENT ON TABLE  interactions IS 'Fact table: every like / share / save / view recorded with a timestamp';
COMMENT ON TABLE  followers    IS 'Self referencing many-to-many: who follows whom';
COMMENT ON COLUMN posts.post_type IS 'text | image | video | link';
