-- ============================================================
--  Secondary indexes
--  Every index below exists because a query in queries/catalog.js
--  filters, joins or sorts on that column. Primary keys and UNIQUE
--  constraints already create their own indexes, so they are not
--  repeated here.
--  The index lab can drop and recreate exactly this set at runtime.
-- ============================================================

-- posts: "all posts by this author", "posts in the last N days"
CREATE INDEX IF NOT EXISTS idx_posts_user_id      ON posts (user_id);
CREATE INDEX IF NOT EXISTS idx_posts_created_at   ON posts (created_at DESC);

-- comments: counting comments per post is the hot path
CREATE INDEX IF NOT EXISTS idx_comments_post_id   ON comments (post_id);
CREATE INDEX IF NOT EXISTS idx_comments_user_id   ON comments (user_id);

-- followers: the PK covers (follower_id, followee_id) so "who do I follow"
-- is already fast. "who follows me" needs the reverse order.
CREATE INDEX IF NOT EXISTS idx_followers_followee ON followers (followee_id);

-- interactions: the 150k+ row fact table, and where indexing pays off most
CREATE INDEX IF NOT EXISTS idx_interactions_post_id     ON interactions (post_id);
CREATE INDEX IF NOT EXISTS idx_interactions_user_id     ON interactions (user_id);
CREATE INDEX IF NOT EXISTS idx_interactions_created_at  ON interactions (created_at DESC);

-- Composite index: supports "likes on this post" without touching the heap
-- for the type check. Column order matters - post_id is the selective one.
CREATE INDEX IF NOT EXISTS idx_interactions_post_type
    ON interactions (post_id, interaction_type);

-- Partial index: shares are ~8% of rows, so the index is small and the
-- planner can use it for share-only reporting.
CREATE INDEX IF NOT EXISTS idx_interactions_shares_only
    ON interactions (post_id)
    WHERE interaction_type = 'share';

ANALYZE;
