'use strict';

/**
 * Creates the database objects.
 *   node db/migrate.js            -> create anything that is missing
 *   node db/migrate.js --fresh    -> drop every table first, then create
 */

const fs = require('fs');
const path = require('path');
const { pool } = require('./pool');

const fresh = process.argv.includes('--fresh');
const read = (file) => fs.readFileSync(path.join(__dirname, file), 'utf8');

const DROP_ALL = `
  DROP VIEW  IF EXISTS v_daily_engagement CASCADE;
  DROP VIEW  IF EXISTS v_user_engagement  CASCADE;
  DROP VIEW  IF EXISTS v_post_engagement  CASCADE;
  DROP TABLE IF EXISTS interactions CASCADE;
  DROP TABLE IF EXISTS comments     CASCADE;
  DROP TABLE IF EXISTS followers    CASCADE;
  DROP TABLE IF EXISTS posts        CASCADE;
  DROP TABLE IF EXISTS users        CASCADE;
`;

async function tableExists(name) {
  const { rows } = await pool.query('SELECT to_regclass($1) AS oid', [name]);
  return rows[0].oid !== null;
}

async function main() {
  const client = await pool.connect();
  try {
    if (fresh) {
      process.stdout.write('Dropping existing objects... ');
      await client.query(DROP_ALL);
      console.log('done');
    }

    if (await tableExists('users')) {
      if (!fresh) console.log('Tables already exist, leaving them in place.');
    } else {
      process.stdout.write('Creating tables... ');
      await client.query(read('schema.sql'));
      console.log('done');
    }

    process.stdout.write('Creating views... ');
    await client.query(read('views.sql'));
    console.log('done');

    process.stdout.write('Creating indexes... ');
    await client.query(read('indexes.sql'));
    console.log('done');

    console.log('\nDatabase is ready. Next: npm run db:seed');
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error('\nMigration failed:', err.message);
  process.exit(1);
});
