# Social Media Analytics Engine

A relational database system that stores social media activity and analyses it with advanced SQL: window functions, CTEs, correlated subqueries, views, and measurable index tuning.

The web interface is not a wrapper around a spreadsheet. Every number on screen is produced by a SQL query that runs when you load the page, and the app shows you that SQL.

```
PostgreSQL  ←  Node.js + Express API  ←  vanilla JS frontend
  5 tables        13 catalog queries        6 sections, SVG charts
  3 views         EXPLAIN ANALYZE           no build step
  10 indexes      read-only SQL console     no CDN dependency
```

Point it at an empty database and it builds itself: schema, views, indexes and
roughly 180,000 rows of generated activity, on first boot.

---

## What it does

| Section | What it demonstrates |
|---|---|
| Overview | Aggregates and views feeding a dashboard, derived at query time |
| Explore data | Parameterised search, joins, per-user drill-down |
| Query lab | 13 analytical queries with their SQL shown next to live results |
| SQL console | Your own SELECT, run inside a read-only transaction with a timeout |
| Index lab | Drop indexes, benchmark, rebuild, benchmark again |
| Schema | Live read of `information_schema`, plus the normalisation argument |

---

## Running it on your own machine

You need Node.js 18 or newer and PostgreSQL 14 or newer.

```bash
npm install
createdb social_analytics
cp .env.example .env        # then set DATABASE_URL
npm start
```

Open http://localhost:3000. On the very first run the server finds an empty
database, creates the tables, views and indexes, generates the dataset, and
shows you its progress while it does it. That takes about eight seconds and
happens once. Every later start reuses what is already there.

### Or with Docker, one command

```bash
docker compose up
```

That starts PostgreSQL and the app together and needs no `.env` file at all.

### Scripts, if you want manual control

| Command | What it does |
|---|---|
| `npm start` | Start the server, setting the database up if it is empty |
| `npm run dev` | Same, restarting when files change |
| `npm run db:setup` | Create tables, views and indexes if missing |
| `npm run db:fresh` | Drop everything and recreate it empty |
| `npm run db:seed` | Fill the tables with generated data |
| `npm run db:reset` | `db:fresh` followed by `db:seed` |

Set `AUTO_SETUP=false` to stop the server touching the schema, and use the
scripts instead. Seed volume is controlled by the `SEED_` variables in
`.env.example`.

---

## Deploying to Render

**Before you start.** Render's free PostgreSQL expires 30 days after you create
it, with a 14-day grace period before the data is deleted. Free web services
also spin down after 15 minutes without traffic and take about a minute to wake
up. Create the database close to your submission date, and open the site a few
minutes before a demo so it is already awake. Check Render's current free tier
terms, since they change.

### The blueprint

1. Push this project to a GitHub repository.
2. In Render, choose **New → Blueprint** and select the repo. It reads
   `render.yaml` and proposes one web service plus one free PostgreSQL database,
   already wired together.
3. Click **Apply**.
4. Open the service URL.

There is no step five. The first request shows the setup screen while the
server builds its schema and seeds itself, then the dashboard appears. You
never need shell access, and you never run a migration by hand.

### Creating the services by hand instead

1. **New → PostgreSQL**, free plan. Copy its **Internal Database URL**.
2. **New → Web Service**, connect the repo, runtime `Node`, build command
   `npm install`, start command `npm start`, health check path `/api/health`.
3. Add one environment variable: `DATABASE_URL`, set to the internal URL.
4. Deploy, then open the URL.

### Deploying anywhere else

Any host that runs a Node process and hands it a `DATABASE_URL` works the same
way, because the app sets itself up on boot: Railway, Fly.io, a VPS with the
Dockerfile, or your own machine. SSL is enabled automatically for hosted
databases and skipped for localhost; override with `PGSSL=off` if you need to.

### If something goes wrong

| Symptom | Cause and fix |
|---|---|
| Setup screen says the database is not reachable | `DATABASE_URL` is wrong or the database is still starting. The server retries ten times before giving up. |
| `DATABASE_URL is not set` in the logs | The environment variable is missing on the web service. |
| Setup screen never finishes | Check the service logs. Every step prints a line prefixed `[setup]`. |
| `no pg_hba.conf entry ... SSL off` | You set `PGSSL=off` against a hosted database. Remove it. |
| `self signed certificate` locally | Set `PGSSL=off` in `.env` for a local database. |
| First request after a break takes a minute | The free web service spun down. This is expected. |

---

## Project layout

```
server.js              Express app, static file serving, shutdown handling
Dockerfile             Container image
docker-compose.yml     App plus PostgreSQL, for one-command local runs
render.yaml            Render blueprint: web service + database
db/
  schema.sql           Tables, keys, constraints
  views.sql            v_post_engagement, v_user_engagement, v_daily_engagement
  indexes.sql          The 10 secondary indexes
  drop_indexes.sql     Removes exactly those 10, used by the index lab
  migrate.js           Applies the SQL files
  seed.js              Generates the dataset, as a script or as a function
  bootstrap.js         First-run setup: builds and seeds the database on boot
  pool.js              Connection pool and timing helper
queries/
  catalog.js           The 13 analytical queries, with the concepts each one shows
routes/
  api.js               Every HTTP endpoint
public/
  index.html           The single page
  app.js               Views, tables, hand-drawn SVG charts
  styles.css           Styling
docs/
  DBMS-NOTES.md        Normalisation, indexing rationale, measured results
```

---

## API reference

| Method | Endpoint | Returns |
|---|---|---|
| GET | `/api/health` | Server time and PostgreSQL version |
| GET | `/api/status` | First-run setup progress; everything else returns 503 until this reports ready |
| GET | `/api/overview` | Totals, 45-day series, top posts, top users, interaction mix |
| GET | `/api/users?search=&sort=&limit=` | Users with engagement metrics |
| GET | `/api/users/:id` | One user, their best posts, their latest activity |
| GET | `/api/posts?search=&type=&limit=` | Posts with engagement metrics |
| GET | `/api/queries` | The query catalog, including the SQL text |
| POST | `/api/queries/:id/run` | Runs one catalog query, returns rows and timing |
| POST | `/api/sql` | Runs a user-written SELECT, read only, capped at 200 rows |
| GET | `/api/indexes` | Every index on the database with its size |
| POST | `/api/indexes/enable` \| `/disable` | Creates or drops the secondary indexes |
| POST | `/api/benchmark` | EXPLAIN ANALYZE timings and the scan types used |
| GET | `/api/schema` | Columns, constraints and row counts from the catalog |

### A note on SQL injection, if you are asked

The browser never sends SQL that the server trusts.

- Catalog queries are looked up by id in `queries/catalog.js`. The client sends `trending`, not a query.
- Search and filter endpoints use parameterised queries (`$1`, `$2`), so user text is never concatenated into SQL. Sort columns are checked against an allow-list, because a column name cannot be a bind parameter.
- The SQL console is the one place user SQL runs. It rejects anything that is not a single `SELECT` or `WITH`, blocks write keywords, runs inside `BEGIN READ ONLY` with a `statement_timeout`, wraps the query in an outer `LIMIT 200`, and rolls back. Set `ALLOW_CUSTOM_SQL=false` to switch it off entirely.

---

## Measured results

From a run with 600 users, 6,000 posts, 24,000 comments, 14,000 follow edges and 177,342 interactions, using average execution time over three runs of `EXPLAIN ANALYZE`:

| Query | Without indexes | With indexes | Change |
|---|---|---|---|
| Users above the average follower count | 2011.8 ms | 13.9 ms | 145× faster |
| Accounts that never engage | 76.5 ms | 1.5 ms | 51× faster |
| Trending in the last 7 days | 75.3 ms | 22.7 ms | 3.3× faster |
| Interaction mix of the busiest posts | 44.6 ms | 44.5 ms | no change |

The last row is worth keeping. That query reads most of the fact table regardless, so a sequential scan is already the planner's best option and an index cannot help. Being able to say why is a better answer than claiming indexes always speed things up.

Your own numbers will differ with hardware and data volume. Re-run the benchmark and quote what you measure.
