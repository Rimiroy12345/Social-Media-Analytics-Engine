# DBMS notes

Written for the project report and for the questions you are likely to be asked about it.

---

## 1. Entity relationship design

```
                 ┌──────────┐
                 │  users   │
                 └────┬─────┘
        ┌─────────────┼──────────────┬──────────────┐
        │ 1:N         │ 1:N          │ 1:N          │ M:N (self)
        ▼             ▼              ▼              ▼
   ┌────────┐   ┌──────────┐   ┌──────────────┐  ┌───────────┐
   │ posts  │   │ comments │   │ interactions │  │ followers │
   └───┬────┘   └──────────┘   └──────────────┘  └───────────┘
       │ 1:N          ▲                ▲
       └──────────────┴────────────────┘
```

| Relationship | Type | How it is implemented |
|---|---|---|
| user writes posts | 1:N | `posts.user_id` → `users.user_id` |
| post receives comments | 1:N | `comments.post_id` → `posts.post_id` |
| user writes comments | 1:N | `comments.user_id` → `users.user_id` |
| user engages with post | M:N | `interactions` with its own attributes |
| user follows user | M:N, recursive | `followers(follower_id, followee_id)` |

`interactions` is an **associative entity**, not a plain junction table: besides the two foreign keys it carries `interaction_type` and `created_at`, which belong to the relationship rather than to either participant. That is exactly the case where a junction table gains its own attributes and a surrogate key.

`followers` is a **recursive many-to-many** relationship: the same entity on both sides. Its composite primary key `(follower_id, followee_id)` makes a duplicate follow impossible, and a CHECK constraint stops a user following themselves.

---

## 2. Normalisation

**First normal form.** Every attribute holds one atomic value. There is no `likes` column holding a comma separated list of user ids, and no `comment_1`, `comment_2`, `comment_3` repeating group. Each like and each comment is its own row.

**Second normal form.** 2NF only bites when a table has a composite primary key. The only one here is `followers(follower_id, followee_id)`, and its single non-key attribute `followed_at` depends on both halves: the date one person started following another is meaningless if you drop either id. Every other table has a single-column surrogate key, so partial dependency cannot arise.

**Third normal form.** No non-key attribute depends on another non-key attribute. `posts` stores `user_id` and nothing else about the author — not the username, not the country. If the username were copied into `posts`, then `username` would depend on `user_id`, which depends on `post_id`: a transitive dependency, and a guarantee that renaming a user leaves stale copies behind. The same logic keeps `interactions` down to ids, a type and a timestamp.

**Derived data is deliberately absent.** There is no `like_count` on `posts` and no `follower_count` on `users`. Both are computed by views. Storing them would be a denormalisation that buys read speed at the cost of needing triggers or application code to keep them correct, and any bug there produces a database that disagrees with itself. The trade-off is worth naming in a viva: at social network scale you eventually *do* denormalise counters, and then you accept the maintenance burden on purpose.

**Constraints doing real work.**

| Constraint | Table | What it prevents |
|---|---|---|
| `UNIQUE (username)`, `UNIQUE (email)` | users | Two accounts with one identity |
| `CHECK (post_type IN (...))` | posts | An invalid format reaching the table |
| `CHECK (follower_id <> followee_id)` | followers | Self-follow |
| `PRIMARY KEY (follower_id, followee_id)` | followers | Following the same person twice |
| `UNIQUE (post_id, user_id, interaction_type)` | interactions | Counting one person's like twice |
| `ON DELETE CASCADE` | all FKs | Orphan rows after a user is deleted |

---

## 3. Views

| View | Grain | Why it exists |
|---|---|---|
| `v_post_engagement` | one row per post | Every query that needs an engagement score builds on it, so the weighting is defined once |
| `v_user_engagement` | one row per user | Creator level rollup, including follower counts |
| `v_daily_engagement` | one row per day | Time series for trend queries and the dashboard chart |

`v_post_engagement` is built from two aggregate CTEs joined back to `posts`. That structure matters: aggregating `interactions` and `comments` in a single join would multiply rows together and inflate both counts. Aggregating each side separately first and then joining keeps the grain at one row per post. This is a classic fan-out trap and a good thing to be able to explain.

The engagement weights used everywhere: view 0.2, like 1, save 2, comment 2, share 3. A share is worth fifteen views because it puts the post in front of a new audience.

---

## 4. SQL techniques, and where each one appears

| Technique | Query in the catalog |
|---|---|
| Inner joins across three tables | Highest engagement posts |
| `GROUP BY` with `HAVING` | Highest engagement posts |
| `FILTER (WHERE ...)` conditional aggregate | Highest engagement posts, hourly pattern |
| Common table expressions | Creator leaderboard, trending, daily trend, interaction mix |
| `RANK()`, `DENSE_RANK()`, `PERCENT_RANK()` | Creator leaderboard |
| `RANK() OVER (PARTITION BY ...)` | Creator leaderboard, rank within country |
| `ROW_NUMBER()` to take top N per group | Each creator's best three posts |
| `AVG() OVER (PARTITION BY ...)` | Post performance against its author |
| Window frame `ROWS BETWEEN 6 PRECEDING AND CURRENT ROW` | Daily activity, moving average |
| `LAG()` | Daily activity, follower growth |
| Running total with `SUM() OVER (ORDER BY ...)` | Daily activity, follower growth |
| `SUM(count(*)) OVER ()` for percent of total | Hourly pattern, interaction mix |
| Correlated subquery | Users above the average follower count |
| Scalar subquery over a derived table | Users above the average follower count |
| `NOT EXISTS` anti-join | Accounts that never engage |
| Self join | Mutual connections |
| Date handling: `date_trunc`, `EXTRACT`, intervals | Trending, daily trend, follower growth |

**RANK vs DENSE_RANK**, since it is nearly always asked: with scores 90, 90, 85, `RANK()` gives 1, 1, 3 and `DENSE_RANK()` gives 1, 1, 2. `RANK` leaves a gap the size of the tie; `DENSE_RANK` does not. `ROW_NUMBER()` would give 1, 2, 3 and break the tie arbitrarily, which is what you want when picking exactly three rows per group.

---

## 5. Indexing

Ten secondary indexes, each justified by a query that filters, joins or sorts on that column.

| Index | Column(s) | Serves |
|---|---|---|
| `idx_posts_user_id` | posts(user_id) | Joining posts to their author |
| `idx_posts_created_at` | posts(created_at DESC) | Recent posts |
| `idx_comments_post_id` | comments(post_id) | Comment counts per post |
| `idx_comments_user_id` | comments(user_id) | A user's comment history |
| `idx_followers_followee` | followers(followee_id) | "Who follows me" |
| `idx_interactions_post_id` | interactions(post_id) | Engagement per post |
| `idx_interactions_user_id` | interactions(user_id) | Engagement by a user, the anti-join |
| `idx_interactions_created_at` | interactions(created_at DESC) | Time window filters |
| `idx_interactions_post_type` | interactions(post_id, interaction_type) | Composite: likes on a given post |
| `idx_interactions_shares_only` | interactions(post_id) WHERE type = 'share' | Partial: small index for share reporting |

Three points worth making in the report.

**The primary key already gives you an index.** `followers` has a composite primary key on `(follower_id, followee_id)`, so "who do I follow" is already fast. "Who follows me" is not, because a B-tree on `(a, b)` cannot be used to search on `b` alone. That is why `idx_followers_followee` exists and why column order in a composite index matters.

**A partial index is smaller.** Shares are about 7% of the interactions table, so `idx_interactions_shares_only` indexes only those rows. Less disk, less to keep updated on write.

**Indexes are not free.** Every `INSERT` into `interactions` has to update every index on it. On a write-heavy fact table that is real cost, which is the argument against indexing everything "just in case".

### Measured results

600 users, 6,000 posts, 24,000 comments, 14,000 follows, 177,342 interactions. Average execution time over three runs of `EXPLAIN ANALYZE`.

| Query | No indexes | With indexes | Speed-up | Plan change |
|---|---|---|---|---|
| Users above the average follower count | 2011.8 ms | 13.9 ms | 145× | Seq Scan → Bitmap Index Scan |
| Accounts that never engage | 76.5 ms | 1.5 ms | 51× | Seq Scan → Index Only Scan |
| Trending in the last 7 days | 75.3 ms | 22.7 ms | 3.3× | Seq Scan → Bitmap Index Scan |
| Highest engagement posts | 205.9 ms | 275.8 ms | none | Already using PK indexes |
| Interaction mix of the busiest posts | 44.6 ms | 44.5 ms | none | Seq Scan either way |

The two rows with no improvement are the interesting ones.

*Highest engagement posts* joins and groups almost the whole table. The planner was already using primary key indexes for the joins, so the extra indexes change nothing, and the small difference between the two numbers is measurement noise rather than a real slowdown.

*Interaction mix* has to read every row of `interactions` to find the ten busiest posts. When a query touches most of a table, a sequential scan is genuinely cheaper than an index scan, because an index lookup means jumping between the index and the heap for every row. The planner knows this and chooses the scan. An index you added that the planner refuses to use is still costing you write performance.

The rule underneath all of it: **indexes pay off when a query is selective.** Both 25× and 48× cases look up a small slice of a large table. The flat cases read the whole thing.

---

## 6. Query optimisation beyond indexes

- `ANALYZE` runs at the end of seeding. Without current statistics the planner guesses row counts badly and can pick the wrong join strategy entirely.
- `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)` is what the benchmark endpoint runs. The `Execution Time` it reports excludes network transfer, so the numbers measure the database rather than the connection.
- Aggregating before joining, as `v_post_engagement` does, keeps intermediate result sets small.
- `LIMIT` with `ORDER BY` on an indexed column lets PostgreSQL stop early instead of sorting everything.
- The correlated subquery in "users above the average follower count" is deliberately written the slow way. Rewriting it as a `GROUP BY` with a join would be faster even without indexes, and comparing the two is a good extension if you want one.

---

## 7. Possible extensions

If you are asked what you would do next:

- Materialised views for the daily rollup, refreshed on a schedule, with the staleness trade-off that brings
- Table partitioning on `interactions` by month, so old partitions can be dropped cheaply
- A BRIN index on `interactions.created_at`, which suits naturally time-ordered data and is far smaller than a B-tree
- Triggers maintaining denormalised counters, and a discussion of when that becomes worth it
- Full text search on `posts.content` with a GIN index on `to_tsvector`
